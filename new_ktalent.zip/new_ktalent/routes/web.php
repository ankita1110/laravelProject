<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('/login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::group(['prefix' => 'agency'], function () {
    Route::get('getInvite', [
        'as'   => 'agency.getInvite',
        'uses' => 'AgencyController@getInvite'
    ]);
    Route::post('StoreInvite', [
        'as'   => 'agency.storeInvite',
        'uses' => 'AgencyController@storeInvite'
    ]);
});

Route::group(['prefix' => 'company'], function () {
    Route::get('getInvite', [
        'as'   => 'company.getInvite',
        'uses' => 'CompanyController@getInvite'
    ]);
    Route::post('StoreInvite', [
        'as'   => 'company.storeInvite',
        'uses' => 'CompanyController@storeInvite'
    ]);
});

Route::group(['prefix' => 'applicant'], function () {
    Route::get('getInvite', [
        'as'   => 'applicant.getInvite',
        'uses' => 'ApplicantController@getInvite'
    ]);
    Route::post('StoreInvite', [
        'as'   => 'applicant.storeInvite',
        'uses' => 'ApplicantController@storeInvite'
    ]);
});

Route::group(["prefix"=>'agency'], function ()
{
    //For Agency module
    Route::get('/list', [
        'as'   => 'agency.list',
        'uses' => 'AgencyController@index'
    ]);
    Route::get('/add', [
        'as'   => 'agency.post',
        'uses' => 'AgencyController@create'
    ]);
    Route::post('/add', [
        'as'   => 'agency.post',
        'uses' => 'AgencyController@store'
    ]);
    Route::get('/edit', [
        'as'   => 'agency.edit',
        'uses' => 'AgencyController@edit'
    ]);
    Route::PATCH('/edit/{id}', [
        'as'   => 'agency.update',
        'uses' => 'AgencyController@update'
    ]);
    Route::get('/delete', [
        'as'   => 'agency.delete',
        'uses' => 'AgencyController@destroy'
    ]);
    Route::get('/invite', [
        'as'   => 'agency.invite',
        'uses' => 'AgencyController@invite'
    ]);
    Route::post('/sendinvite', [
        'as'   => 'agency.invite.send',
        'uses' => 'AgencyController@sendinvite'
    ]);
});

Route::resource('job', 'JobController');

Route::get('company/invite', [
    'as'   => 'company.invite',
    'uses' => 'CompanyController@invite'
]);
Route::post('company/sendinvite', [
    'as'   => 'company.invite.send',
    'uses' => 'CompanyController@sendinvite'
]);
Route::resource('company', 'CompanyController');

Route::get('applicant/invite', [
    'as'   => 'applicant.invite',
    'uses' => 'ApplicantController@invite'
]);
Route::post('applicant/sendinvite', [
    'as'   => 'applicant.invite.send',
    'uses' => 'ApplicantController@sendinvite'
]);
Route::resource('applicant', 'ApplicantController');

/* Company User Post Job Route */
Route::get('/post_job',[
    'as'    => 'job.postjob',
    'uses'  => 'JobController@add_a_job'
]);

Route::get('/list_job',[
    'as'    => 'job.listjob',
    'uses'  => 'JobController@listjob'
]);

Route::post('/post_job','JobController@company_save_job');

Route::get('/com_job/edit/{id}', [
    'as'   => 'company.job.edit',
    'uses' => 'JobController@company_job_edit'
]);

Route::post('/update_post_job/{id}',[
    'as'    => 'company.job.update',
    'uses'  => 'JobController@update_post_job'
]);

/* Applicant Section for Apply Job */
Route::get('/apply_job',[
    'as'    => 'applicant.list_job',
    'uses'  => 'ApplicantController@listed_job'
]);
Route::post('/apply_job','ApplicantController@apply_job');

/* Agency add Applicant Users */
Route::get('applicant_add',[
    'as'    => 'applicant.add_applicant_form',
    'uses'  => 'AgencyController@add_applicant_form'
]);

Route::post('/add_applicant_agency','AgencyController@add_applicant_from_agency');

Route::get('list_applicant',[
    'as'    => 'applicant.list_applicant',
    'uses'  =>  'AgencyController@list_applicant'
]);

Route::get('/applicant_edit', [
        'as'   => 'applicant_ag.edit',
        'uses' => 'AgencyController@app_edit'
    ]);
Route::PATCH('/applicant_edit/{id}', [
    'as'   => 'applicant_ag.update',
    'uses' => 'AgencyController@app_update'
]);
Route::get('/applicant_delete/{id}', [
    'as'   => 'applicant_ag.delete',
    'uses' => 'AgencyController@app_delete'
]);

Route::get('/agency_associate', [
    'as'   => 'agency.associate',
    'uses' => 'AgencyController@agency_assoc'
]);

Route::post('/agency_associate','AgencyController@final_associate_agency');

/* Company Services for Company User */ 
Route::get('/company_services', [
    'as'   => 'company.services',
    'uses' => 'CompanyController@com_services'
]);
Route::post('/accept_by_company',[
    'as'    => 'company.accept',
    'uses'  =>  'CompanyController@accept_company'
]);

/* Company find agency search and send invitation */
Route::get('/find_agency',[
    'as'    => 'company.find_agency',
    'uses'  => 'CompanyController@find_agency'
]);

Route::post('/find_agency',[
    'as'    => 'company.find_by_agency',
    'uses'  => 'CompanyController@find_agency_post'
]);

/* Send Invitation to Agency by Company */
Route::post('/send_invite_agency',[
    'as'    => 'company.invite_agency',
    'uses'  => 'CompanyController@invite_agency'
]);

/* Agency find Company search and send invitation */
Route::get('/find_company',[
    'as'    => 'agency.find_company',
    'uses'  => 'AgencyController@find_company'
]);

Route::post('/find_company',[
    'as'    => 'agency.find_by_agency',
    'uses'  => 'AgencyController@find_company_post'
]);

/* Send Invitation to Company by Agency */
Route::post('/send_invite_company',[
    'as'    => 'agency.invite_company',
    'uses'  => 'AgencyController@invite_company'
]);