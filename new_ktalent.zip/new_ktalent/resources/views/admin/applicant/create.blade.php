@extends('layouts.app')

@section('title')
    Admin area: Add Applicant
@stop

@section('content')
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid margin-right-15">
        <div class="navbar-header">
            <a class="navbar-brand bariol-thin" href="#"></a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-main-menu">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="nav-main-menu">
            <ul class="nav navbar-nav">
                <li><a href="{{ url('/home') }}">Dashboard</a></li>
                <li><a href="{{ url('/agency/list') }}">Agency</a></li>
                <li><a href="{{ url('/job') }}">Job</a></li>
                <li><a href="{{ url('/company') }}">Company</a></li>
                <li><a href="{{ url('/applicant') }}">Applicant</a></li>
                
            </ul>
            <div class="navbar-nav nav navbar-right">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
                        <img src="" width="30">
                        <span id="nav-email">{{ Auth::user()->email }}</span><i class="fa fa-caret-down"></i>
                    </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                            </li>
                        </ul>
                </li>
            </div><!-- nav-right -->
        </div><!--/.nav-collapse -->
    </div>
</div>
    <div class="row">
        <div class="col-sm-3 col-md-2 col-xs-12 sidebar">
                <ul class="nav nav-sidebar">
                    <li class="active"><a href="{{ URL('/applicant') }}"><i class="fa fa-tachometer"></i>Applicant List</a></li>
                    <li><a href="{{URL('/applicant/create')}}"><i class="fa fa-tachometer"></i>Add New</a></li>
                    <li><a href="{{URL('/applicant/invite')}}"><i class="fa fa-tachometer">Send Invitation</i></a></li>
                </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i>Applicant</h3>
                        </div>
                    </div>
                </div>
                
                <div class="panel-body">
                    <div class="col-md-12 col-xs-12">
                        <h4>Applicant data</h4>
                            <form method="POST" action="{{URL('/applicant')}}" enctype="multipart/form-data">
                                {{csrf_field()}}
                                <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                    <!--picture file field-->
                                    <div class="form-group col-md-6">
                                        <label for="picture">Picture</label>
                                        <input class="form-control" name="picture" type="file" id="picture">
                                    </div>
                                    <!--CV file field-->
                                    <div class="form-group col-md-6">
                                        <label for="cv">CV</label>
                                        <input class="form-control" name="cv" type="file" id="cv">
                                    </div>
                                </div>
                            <!-- first_name text field -->
                            <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                <div class="form-group col-md-4">
                                    <label for="first_name">First Name :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="first_name" type="text" id="first_name">
                                </div>
                                <!-- middle_name text field -->
                                <div class="form-group col-md-4">
                                    <label for="middle_name">Middle Name :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="middle_name" type="text" id="middle_name">
                                </div>
                                <!-- last_name text field -->
                                <div class="form-group col-md-4">
                                    <label for="last_name">Last Name :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="last_name" type="text" id="last_name">
                                </div>
                                <!-- father_spouse_name text field -->
                                <div class="form-group col-md-6">
                                    <label for="father_spouse_name">Father/Spouse Name :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="father_spouse_name" type="text" id="father_spouse_name">
                                </div>
                                <!-- mother_name text field -->
                                <div class="form-group col-md-6">
                                    <label for="mother_name">Mother Name :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="mother_name" type="text" id="mother_name">
                                </div>
                                <!-- mobile_no text field -->
                                <div class="form-group col-md-6">
                                    <label for="mobile_no">Mobile Number :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="mobile_no" type="text" id="mobile_no">
                                </div>
                                <!-- alternate_mobile_no text field -->
                                <div class="form-group col-md-6">
                                    <label for="alternate_mobile_no">Alternate Mobile Number :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="alternate_mobile_no" type="text" id="alternate_mobile_no">
                                </div>
                            </div>
                            <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">

                                <!-- email_id text field -->
                                <div class="form-group col-md-6">
                                    <label for="email_id">E Mail id :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="email_id" type="text" id="email_id">
                                </div>
                                <!-- alternate_email_id text field -->
                                <div class="form-group col-md-6">
                                    <label for="alternate_email_id">Alternate E Mail id  :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="alternate_email_id" type="text" id="alternate_email_id">
                                </div>
                            <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                <!-- address1 text field -->
                                <div class="form-group col-md-12">
                                    <label for="address1">Address Line 1 :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="address1" type="text" id="address1">
                                </div>
                                <!-- address2 text field -->
                                <div class="form-group col-md-6">
                                    <label for="address2">Address Line 2 :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="address2" type="text" id="address2">
                                </div>
                                <!-- address3 text field -->
                                <div class="form-group col-md-6">
                                    <label for="address3">Address Line 3 :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="address3" type="text" id="address3">
                                </div>
                            </div>
                            <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                <!-- state name text field -->
                                <div class="form-group col-md-3">
                                    <label for="state">State :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="state" type="text" id="state">
                                </div>
                                <!-- district text field -->
                                <div class="form-group col-md-3">
                                    <label for="district">District :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="district" type="text" id="district">
                                </div>
                                <!-- country text field -->
                                <div class="form-group col-md-3">
                                    <label for="country">Country :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="country" type="text" id="country">
                                </div>
                                <!-- pin text field -->
                                <div class="form-group col-md-3">
                                    <label for="pin">PIN :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="pin" type="text" id="pin">
                                </div>
                            </div>
                                <!-- education text field -->
                                <div class="form-group col-md-6">
                                    <label for="education">Education :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="education" type="text" id="education">
                                </div>
                                <!-- experience text field -->
                                <div class="form-group col-md-6">
                                    <label for="experience">Experience :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="experience" type="text" id="experience">
                                </div>
                                <!-- hobbies text field -->
                                <div class="form-group col-md-6">
                                    <label for="hobbies">Hobbies and Interest :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="hobbies" type="text" id="hobbies">
                                </div>
                                <!-- reference text field -->
                                <div class="form-group col-md-6">
                                    <label for="reference">Reference :</label>
                                    <input class="form-control" placeholder="" autocomplete="off" name="reference" type="text" id="reference">
                                </div>
                            <input class="btn btn-info pull-right " type="submit" value="Save">
                             </div>
                            </form>
                            </div>
                            
                        </div>

            </div>
        </div>
    </div>
@stop

@section('footer_scripts')
    <script>
        $(".delete").click(function(){
            return confirm("Are you sure to delete this item?");
        });
    </script>
@stop