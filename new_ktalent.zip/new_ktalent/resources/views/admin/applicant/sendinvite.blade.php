<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Agency Invitation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/bootstrap.min.css') !!}
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/style.css') !!}
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/baselayout.css') !!}
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/fonts.css') !!}
    {!! HTML::style('//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css') !!}
    {!! HTML::style('//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css') !!}
    {!! HTML::style('//cdn.datatables.net/fixedcolumns/3.2.3/css/fixedColumns.dataTables.min.css') !!}
    {!! HTML::style('//cdn.datatables.net/buttons/1.4.2/css/buttons.dataTables.min.css') !!}
</head>
<body>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="col-xs-12 main">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-md-12">
                                    <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i> Create Agency</h3>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="col-md-12 col-xs-12">
                                <h4>Applicant data</h4>
                                {!! Form::open(array('route' => 'applicant.storeInvite','method'=>'POST', 'files'=>'true')) !!}
                                <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                    <!--picture file field-->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('picture', 'Picture') !!}
                                        {!! Form::file('picture', ['class'=>'form-control']) !!}
                                    </div>
                                    <!--CV file field-->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('cv', 'CV') !!}
                                        {!! Form::file('cv', ['class'=>'form-control']) !!}
                                    </div>
                                </div>
                                <!-- first_name text field -->
                                <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                    <div class="form-group col-md-4">
                                        {!! Form::label('first_name','First Name :') !!}
                                        {!! Form::text('first_name', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- middle_name text field -->
                                    <div class="form-group col-md-4">
                                        {!! Form::label('middle_name','Middle Name :') !!}
                                        {!! Form::text('middle_name', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- last_name text field -->
                                    <div class="form-group col-md-4">
                                        {!! Form::label('last_name','Last Name :') !!}
                                        {!! Form::text('last_name', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- father_spouse_name text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('father_spouse_name','Father/Spouse Name :') !!}
                                        {!! Form::text('father_spouse_name', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- mother_name text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('mother_name','Mother Name :') !!}
                                        {!! Form::text('mother_name', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- mobile_no text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('mobile_no','Mobile Number :') !!}
                                        {!! Form::text('mobile_no', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- alternate_mobile_no text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('alternate_mobile_no','Alternate Mobile Number :') !!}
                                        {!! Form::text('alternate_mobile_no', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                </div>
                                <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">

                                    <!-- email_id text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('email_id','E Mail id :') !!}
                                        {!! Form::text('email_id', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- alternate_email_id text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('alternate_email_id','Alternate E Mail id  :') !!}
                                        {!! Form::text('alternate_email_id', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                        <!-- address1 text field -->
                                        <div class="form-group col-md-12">
                                            {!! Form::label('address1','Address Line 1 :') !!}
                                            {!! Form::text('address1', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                        </div>
                                        <!-- address2 text field -->
                                        <div class="form-group col-md-6">
                                            {!! Form::label('address2','Address Line 2 :') !!}
                                            {!! Form::text('address2', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                        </div>
                                        <!-- address3 text field -->
                                        <div class="form-group col-md-6">
                                            {!! Form::label('address3','Address Line 3 :') !!}
                                            {!! Form::text('address3', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                        </div>
                                    </div>
                                    <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                        <!-- state name text field -->
                                        <div class="form-group col-md-3">
                                            {!! Form::label('state','State :') !!}
                                            {!! Form::text('state', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                        </div>
                                        <!-- district text field -->
                                        <div class="form-group col-md-3">
                                            {!! Form::label('district','District :') !!}
                                            {!! Form::text('district', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                        </div>
                                        <!-- country text field -->
                                        <div class="form-group col-md-3">
                                            {!! Form::label('country','Country :') !!}
                                            {!! Form::text('country', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                        </div>
                                        <!-- pin text field -->
                                        <div class="form-group col-md-3">
                                            {!! Form::label('pin','PIN :') !!}
                                            {!! Form::text('pin', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                        </div>
                                    </div>
                                    <!-- education text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('education','Education :') !!}
                                        {!! Form::text('education', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- experience text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('experience','Experience :') !!}
                                        {!! Form::text('experience', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- hobbies text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('hobbies','Hobbies and Interest :') !!}
                                        {!! Form::text('hobbies', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- reference text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('reference','Reference :') !!}
                                        {!! Form::text('reference', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                </div>
                            </div>
                            {{--{!! Form::hidden('id') !!}
                            {!! Form::hidden('form_name','user') !!}
                            --}}{!! Form::submit('Save', array("class"=>"btn btn-info pull-right ")) !!}
                            {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
{!! HTML::script('packages/jacopo/laravel-authentication-acl/js/vendor/jquery-1.10.2.min.js') !!}
{!! HTML::script('packages/jacopo/laravel-authentication-acl/js/vendor/bootstrap.min.js') !!}
{!! HTML::script('//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js') !!}
{!! HTML::script('//cdn.datatables.net/fixedcolumns/3.2.3/js/dataTables.fixedColumns.min.js') !!}
{!! HTML::script('//cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js') !!}
</body>
</html>