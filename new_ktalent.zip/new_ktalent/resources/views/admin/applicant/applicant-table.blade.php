<style>
    a.dt-button {
        color: #fff;
        background-color: #5bc0de;
        border-color: #46b8da;
        display: inline-block;
        padding: 6px 12px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.428571429;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        cursor: pointer;
        background-image: none;
        border: 1px solid transparent;
        border-radius: 4px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        -o-user-select: none;
        user-select: none;
    }

    button.dt-button:hover:not(.disabled), div.dt-button:hover:not(.disabled), a.dt-button:hover:not(.disabled),
    button.dt-button:focus:not(.disabled), div.dt-button:focus:not(.disabled), a.dt-button:focus:not(.disabled) {
        border: 1px solid #65c0de;
        background-color: transparent;
        background-image: none;
        color: #65c0de;
    }

</style>
<div class="panel panel-info">
    <div class="panel-heading">
        <h3 class="panel-title bariol-thin"><i
                    class="fa fa-user"></i> {!! $request->all() ? 'Search results:' : 'Applicant' !!}</h3>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-12 table-responsive">
                @if(count($applicant)!=0)
                    <div class="table-responsive inventory__table">
                        <table class="display nowrap table table-hover table-bordered" id="applicant_table">
                            <thead>
                            <tr>
                                <th>Profile</th>
                                <th>First Name</th>
                                <th>Middle Name</th>
                                <th>Last Name</th>
                                <th>Father/Spouse Name</th>
                                <th>Mother Name</th>
                                <th>Mobile Number</th>
                                <th>Email Id</th>
                                <th>Address</th>
                                <th>State</th>
                                <th>District</th>
                                <th>Country</th>
                                <th>Pin</th>
                                <th>Education</th>
                                <th>Experience</th>
                                <th>Hobbies</th>
                                <th>Reference</th>
                                <th style="background-color: #292d2e;color: #fff;">Operations</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($applicant as $key)
                                <tr>
                                    <td>
                                        @if(! empty($key->picture))
                                            <img src="/app/public/images/applicant/{{ $key->picture }}"
                                                 style="width:80px; height:80px; float:left; border-radius:50%; margin-right:25px;">
                                        @else
                                            <img src="/app/public/images/applicant/unknown.jpg"
                                                 style="width:80px; height:80px; float:left; border-radius:50%; margin-right:25px;">
                                        @endif
                                    </td>
                                    <td>{!! $key->first_name !!}</td>
                                    <td>{!! $key->middle_name !!}</td>
                                    <td>{!! $key->last_name !!}</td>
                                    <td>{!! $key->father_spouse_name !!}</td>
                                    <td>{!! $key->mother_name !!}</td>
                                    <td>{!! $key->mobile_no !!}</td>
                                    <td>{!! $key->email_id !!}</td>
                                    <td>{!! $key->address1 !!}</td>
                                    <td>{!! $key->state !!}</td>
                                    <td>{!! $key->district !!}</td>
                                    <td>{!! $key->country !!}</td>
                                    <td>{!! $key->pin !!}</td>
                                    <td>{!! $key->education !!}</td>
                                    <td>{!! $key->experience !!}</td>
                                    <td>{!! $key->hobbies !!}</td>
                                    <td>{!! $key->reference !!}</td>
                                    <td>
                                        <a href="{!! URL::route('applicant.edit', ['id' => $key->id]) !!}"><i
                                                    class="fa fa-pencil-square-o fa-2x"></i></a>
                                        {!! Form::open(['method' => 'DELETE','route' => ['applicant.destroy', $key->id],'style'=>'display:inline']) !!}
                                        {!! Form::button('<i class="fa fa-trash-o fa-2x"></i>', ['type' => 'submit', 'class' => 'btn btn-sm','style'=>'padding: 0px 08px;background: transparent; display: table-cell;vertical-align: top;color: #5bc0de;'] ) !!}
                                        {!! Form::close() !!}
                                    </td>
                                </tr>
                            </tbody>
                            @endforeach
                        </table>
                    </div>
                    {{--<div class="paginator">
                        {!! $agency->appends($request->except(['page']) )->render() !!}
                    </div>--}}
                @else
                    <span class="text-warning"><h5>No results found.</h5></span>
                @endif
            </div>
        </div>
    </div>
</div>
