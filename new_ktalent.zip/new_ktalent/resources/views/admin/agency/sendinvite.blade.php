<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Agency Invitation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/bootstrap.min.css') !!}
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/style.css') !!}
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/baselayout.css') !!}
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/fonts.css') !!}
    {!! HTML::style('//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css') !!}
    {!! HTML::style('//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css') !!}
    {!! HTML::style('//cdn.datatables.net/fixedcolumns/3.2.3/css/fixedColumns.dataTables.min.css') !!}
    {!! HTML::style('//cdn.datatables.net/buttons/1.4.2/css/buttons.dataTables.min.css') !!}
</head>
<body>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="col-xs-12 main">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-md-12">
                                    <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i> Create Agency</h3>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="col-md-12 col-xs-12">
                                <h4>Agency data</h4>
                            {!! Form::open(array('route' => 'agency.storeInvite','method'=>'POST')) !!}
                            <!-- agency name text field -->
                                <div class="form-group col-md-12">
                                    {!! Form::label('name','Name: *') !!}
                                    {!! Form::text('name', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                </div>
                                <div class="parent-warpper col-md-12"
                                     style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                    <!-- person name text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('personname','Contact Person Name: *') !!}
                                        {!! Form::text('person1', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- Designation text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('designation','Designation:') !!}
                                        {!! Form::text('designation1', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- mobileno text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('mobile','Mobile Number (As Individual ): *') !!}
                                        {!! Form::text('contact1', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- email text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('email','E Mail id (As Individual ): *') !!}
                                        {!! Form::text('email1', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                </div>
                                <div class="parent-warpper col-md-12"
                                     style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                    <!-- person name text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('personname','Contact Person Name 2:') !!}
                                        {!! Form::text('person2', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- Designation text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('designation','Designation:') !!}
                                        {!! Form::text('designation2', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- mobileno text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('mobile','Mobile Number (As Individual ):') !!}
                                        {!! Form::text('contact2', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- email text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('email','E Mail id (As Individual ):') !!}
                                        {!! Form::text('email2', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                </div>
                                <div class="parent-warpper col-md-12"
                                     style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                    <!-- person name text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('personname','Contact Person Name 3:') !!}
                                        {!! Form::text('person3', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- Designation text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('designation','Designation:') !!}
                                        {!! Form::text('designation3', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- mobileno text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('mobile','Mobile Number (As Individual ):') !!}
                                        {!! Form::text('contact3', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- email text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('email','E Mail id (As Individual ):') !!}
                                        {!! Form::text('email3', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                </div>
                                <span class="text-danger">{!! $errors->first('email') !!}</span>
                                <div class="parent-warpper col-md-12"
                                     style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                    <div class="form-group col-md-12">
                                        {!! Form::label('address','Address Line 1:') !!}
                                        {!! Form::text('address1', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <div class="form-group col-md-6">
                                        {!! Form::label('address','Address Line 2:') !!}
                                        {!! Form::text('address2', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <div class="form-group col-md-6">
                                        {!! Form::label('address','Address Line 3:') !!}
                                        {!! Form::text('address3', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                </div>
                                <div class="parent-warpper col-md-12"
                                     style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">

                                    <div class="form-group col-md-3">
                                        {!! Form::label('city','City: *') !!}
                                        {!! Form::text('city', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <div class="form-group col-md-3">
                                        {!! Form::label('state','State: *') !!}
                                        {!! Form::text('state', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <div class="form-group col-md-3">
                                        {!! Form::label('pin','Pin:') !!}
                                        {!! Form::text('pin', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <div class="form-group col-md-3">
                                        {!! Form::label('country','Country:') !!}
                                        {!! Form::text('country', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                </div>
                            </div>
                            {!! Form::hidden('id') !!}
                            {!! Form::hidden('form_name','user') !!}
                            {!! Form::submit('Save', array("class"=>"btn btn-info pull-right ")) !!}
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{!! HTML::script('packages/jacopo/laravel-authentication-acl/js/vendor/jquery-1.10.2.min.js') !!}
{!! HTML::script('packages/jacopo/laravel-authentication-acl/js/vendor/bootstrap.min.js') !!}
{!! HTML::script('//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js') !!}
{!! HTML::script('//cdn.datatables.net/fixedcolumns/3.2.3/js/dataTables.fixedColumns.min.js') !!}
{!! HTML::script('//cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js') !!}
</body>
</html>