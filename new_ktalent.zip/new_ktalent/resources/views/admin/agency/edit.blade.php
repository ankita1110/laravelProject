@extends('layouts.app')

@section('title')
    Admin area: Add Agency
@stop

@section('content')
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid margin-right-15">
        <div class="navbar-header">
            <a class="navbar-brand bariol-thin" href="#"></a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-main-menu">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="nav-main-menu">
            <ul class="nav navbar-nav">
                <li><a href="{{ url('/home') }}">Dashboard</a></li>
                <li><a href="{{ url('/agency/list') }}">Agency</a></li>
                <li><a href="{{ url('/job') }}">Job</a></li>
                <li><a href="{{ url('/company') }}">Company</a></li>
                <li><a href="{{ url('/applicant') }}">Applicant</a></li>
                
            </ul>
            <div class="navbar-nav nav navbar-right">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
                        <img src="" width="30">
                        <span id="nav-email">{{ Auth::user()->email }}</span><i class="fa fa-caret-down"></i>
                    </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                            </li>
                        </ul>
                </li>
            </div><!-- nav-right -->
        </div><!--/.nav-collapse -->
    </div>
</div>
    <div class="row">
        <div class="col-sm-3 col-md-2 col-xs-12 sidebar">
                <ul class="nav nav-sidebar">
                    <li class="active"><a href="{{ URL('/agency/list') }}"><i class="fa fa-tachometer"></i> Agency List</a></li>
                    <li><a href="{{URL('/agency/add')}}"><i class="fa fa-tachometer"></i>Add New</a></li>
                    <li><a href="{{URL('/agency/invite')}}"><i class="fa fa-tachometer">Send Invitation</i></a></li>
                </ul>
            </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i> Update Agency</h3>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-xs-12">
                        <h4>Agency data</h4>
                    <form method="POST" action="{!! URL::route('agency.update',['id' => $agency->id]) !!}">    
                        <input type="hidden" name="_method" value="PATCH">
                        {{ csrf_field() }}
                        <!-- agency name text field -->
                                            <!-- agency name text field -->
                        <div class="form-group col-md-12">
                            <label for="name">Name: *</label>
                            <input class="form-control" placeholder="" autocomplete="off" name="name" type="text" value="<?php echo isset($agency->name)? $agency->name:''?>" id="name">
                        </div>
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                            <!-- person name text field -->
                            <div class="form-group col-md-6">
                                <label for="personname">Contact Person Name: *</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="person1" type="text" value="<?php echo isset($agency->person1)? $agency->person1:''?>">
                            </div>
                            <!-- Designation text field -->
                            <div class="form-group col-md-6">
                                <label for="designation">Designation:</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="designation1" type="text" value="<?php echo isset($agency->designation1)? $agency->designation1:''?>">
                            </div>
                            <!-- mobileno text field -->
                            <div class="form-group col-md-6">
                                <label for="mobile">Mobile Number (As Individual ): *</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="contact1" type="number" value="<?php echo isset($agency->contact1)? $agency->contact1:''?>">
                            </div>
                            <!-- email text field -->
                            <div class="form-group col-md-6">
                                <label for="email">E Mail id (As Individual ): *</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="email1" type="email" value="<?php echo isset($agency->email1)? $agency->email1:''?>">
                            </div>
                        </div>
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                            <!-- person name text field -->
                            <div class="form-group col-md-6">
                                <label for="personname">Contact Person Name 2:</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="person2" type="text" value="<?php echo isset($agency->person2)? $agency->person2:''?>">
                            </div>
                            <!-- Designation text field -->
                            <div class="form-group col-md-6">
                                <label for="designation">Designation:</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="designation2" type="text" value="<?php echo isset($agency->designation2)? $agency->designation2:''?>">
                            </div>
                            <!-- mobileno text field -->
                            <div class="form-group col-md-6">
                                <label for="mobile">Mobile Number (As Individual ):</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="contact2" type="number" value="<?php echo isset($agency->contact2)? $agency->contact2:''?>">
                            </div>
                            <!-- email text field -->
                            <div class="form-group col-md-6">
                                <label for="email">E Mail id (As Individual ):</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="email2" type="email" value="<?php echo isset($agency->email2)? $agency->email2:''?>">
                            </div>
                        </div>
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                            <!-- person name text field -->
                            <div class="form-group col-md-6">
                                <label for="personname">Contact Person Name 3:</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="person3" type="text" value="<?php echo isset($agency->person3)? $agency->person3:''?>">
                            </div>
                            <!-- Designation text field -->
                            <div class="form-group col-md-6">
                                <label for="designation">Designation:</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="designation3" type="text" value="<?php echo isset($agency->designation3)? $agency->designation3:''?>">
                            </div>
                            <!-- mobileno text field -->
                            <div class="form-group col-md-6">
                                <label for="mobile">Mobile Number (As Individual ):</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="contact3" type="number" value="<?php echo isset($agency->contact3)? $agency->contact3:''?>">
                            </div>
                            <!-- email text field -->
                            <div class="form-group col-md-6">
                                <label for="email">E Mail id (As Individual ):</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="email3" type="email" value="<?php echo isset($agency->email3)? $agency->email3:''?>">
                            </div>
                        </div>
                        <span class="text-danger"></span>
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                            <div class="form-group col-md-12">
                                <label for="address">Address Line 1:</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="address1" type="text" value="<?php echo isset($agency->address1)? $agency->address1:''?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="address">Address Line 2:</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="address2" type="text" value="<?php echo isset($agency->address2)? $agency->address2:''?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="address">Address Line 3:</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="address3" type="text" value="<?php echo isset($agency->address3)? $agency->address3:''?>">
                            </div>
                        </div>
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">

                            <div class="form-group col-md-3">
                                <label for="city">City: *</label>
                                <input class="form-control" placeholder="" required="required" autocomplete="off" name="city" type="text" value="<?php echo isset($agency->city)? $agency->city:''?>" id="city">
                            </div>
                            <div class="form-group col-md-3">
                                <label for="state">State: *</label>
                                <input class="form-control" placeholder=""  required="required" autocomplete="off" name="state" type="text" value="<?php echo isset($agency->state)? $agency->state:''?>" id="state">
                            </div>
                            <div class="form-group col-md-3">
                                <label for="pin">Pin:</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="pin" type="text" value="<?php echo isset($agency->pin)? $agency->pin:''?>" id="pin">
                            </div>
                            <div class="form-group col-md-3">
                                <label for="country">Country:</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="country" type="text" value="<?php echo isset($agency->country)? $agency->country:''?>" id="country">
                            </div>
                        </div>
                    <input type="submit" name="submit" value="Save" class="btn btn-info pull-right">
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

@section('footer_scripts')
    <script>
        $(".delete").click(function(){
            return confirm("Are you sure to delete this item?");
        });
    </script>
@stop