@extends('layouts.app')

@section('title')
    Admin area: Add Agency
@stop

@section('content')
    <div class="row">
        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container-fluid margin-right-15">
                <div class="navbar-header">
                    <a class="navbar-brand bariol-thin" href="#"></a>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-main-menu">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="nav-main-menu">
                    <ul class="nav navbar-nav">
                        <li><a href="{{ url('/home') }}">Dashboard</a></li>
                        <li><a href="{{ url('/agency/list') }}">Agency</a></li>
                        <li><a href="{{ url('/job') }}">Job</a></li>
                        <li><a href="{{ url('/company') }}">Company</a></li>
                        <li><a href="{{ url('/applicant') }}">Applicant</a></li>
                        
                    </ul>
                    <div class="navbar-nav nav navbar-right">
                        <li class="dropdown dropdown-user">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
                                <img src="" width="30">
                                <span id="nav-email">{{ Auth::user()->email }}</span><i class="fa fa-caret-down"></i>
                            </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        {{ csrf_field() }}
                                    </form>
                                    </li>
                                </ul>
                        </li>
                    </div><!-- nav-right -->
                </div><!--/.nav-collapse -->
            </div>
        </div>

            
<div class="row">
<div class="col-sm-3 col-md-2 col-xs-12 sidebar">
    <ul class="nav nav-sidebar">
        <li class="active"><a href="{{ URL('/agency/list') }}"><i class="fa fa-tachometer"></i> Agency List</a></li>
        <li><a href="{{URL('/agency/add')}}"><i class="fa fa-tachometer"></i>Add New</a></li>
        <li><a href="{{URL('/agency/invite')}}"><i class="fa fa-tachometer">Send Invitation</i></a></li>
    </ul>
</div>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
        <h4>Agency data</h4>
    <form method="POST" action="{{URL('/')}}/agency/add">
        {{ csrf_field() }}
    <!-- agency name text field -->
        <div class="form-group col-md-12">
            <label for="name">Name *</label>
            <input class="form-control" placeholder="" autocomplete="off" name="name" type="text" id="name">
        </div>
    <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
        <!-- person name text field -->
        <div class="form-group col-md-6">
            <label for="personname">Contact Person Name: *</label>
            <input class="form-control" placeholder="" autocomplete="off" name="person1" type="text">
        </div>
        <!-- Designation text field -->
        <div class="form-group col-md-6">
            <label for="designation">Designation:</label>
            <input class="form-control" placeholder="" autocomplete="off" name="designation1" type="text">
        </div>
        <!-- mobileno text field -->
        <div class="form-group col-md-6">
            <label for="mobile">Mobile Number (As Individual ): *</label>
            <input class="form-control" placeholder="" autocomplete="off" name="contact1" type="number">
        </div>
        <!-- email text field -->
        <div class="form-group col-md-6">
            <label for="email">E Mail id (As Individual ): *</label>
            <input class="form-control" placeholder="" autocomplete="off" name="email1" type="text">
        </div>
    </div>
    <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
        <!-- person name text field -->
        <div class="form-group col-md-6">
            <label for="personname">Contact Person Name 2:</label>
            <input class="form-control" placeholder="" autocomplete="off" name="person2" type="text">
        </div>
        <!-- Designation text field -->
        <div class="form-group col-md-6">
            <label for="designation">Designation:</label>
            <input class="form-control" placeholder="" autocomplete="off" name="designation2" type="text">
        </div>
        <!-- mobileno text field -->
        <div class="form-group col-md-6">
            <label for="mobile">Mobile Number (As Individual ):</label>
            <input class="form-control" placeholder="" autocomplete="off" name="contact2" type="number">
        </div>
        <!-- email text field -->
        <div class="form-group col-md-6">
            <label for="email">E Mail id (As Individual ):</label>
            <input class="form-control" placeholder="" autocomplete="off" name="email2" type="email">
        </div>
    </div>
    <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
        <!-- person name text field -->
        <div class="form-group col-md-6">
            <label for="personname">Contact Person Name 3:</label>
            <input class="form-control" placeholder="" autocomplete="off" name="person3" type="text">
        </div>
        <!-- Designation text field -->
        <div class="form-group col-md-6">
            <label for="designation">Designation:</label>
            <input class="form-control" placeholder="" autocomplete="off" name="designation3" type="text">
        </div>
        <!-- mobileno text field -->
        <div class="form-group col-md-6">
            <label for="mobile">Mobile Number (As Individual ):</label>
            <input class="form-control" placeholder="" autocomplete="off" name="contact3" type="number">
        </div>
        <!-- email text field -->
        <div class="form-group col-md-6">
            <label for="email">E Mail id (As Individual ):</label>
            <input class="form-control" placeholder="" autocomplete="off" name="email3" type="text">
        </div>
    </div>
         
    <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
        <div class="form-group col-md-12">
            <label for="address">Address Line 1:</label>
            <input class="form-control" placeholder="" autocomplete="off" name="address1" type="text">
        </div>
        <div class="form-group col-md-6">
            <label for="address">Address Line 2:</label>
            <input class="form-control" placeholder="" autocomplete="off" name="address2" type="text">
        </div>
        <div class="form-group col-md-6">
            <label for="address">Address Line 3:</label>
            <input class="form-control" placeholder="" autocomplete="off" name="address3" type="text">
        </div>
    </div>
    <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">

        <div class="form-group col-md-3">
            <label for="city">City: *</label>
            <input class="form-control" placeholder="" autocomplete="off" name="city" type="text" id="city">
        </div>
        <div class="form-group col-md-3">
            <label for="state">State: *</label>
            <input class="form-control" placeholder="" autocomplete="off" name="state" type="text" id="state">
        </div>
        <div class="form-group col-md-3">
            <label for="pin">Pin:</label>
            <input class="form-control" placeholder="" autocomplete="off" name="pin" type="text" id="pin">
        </div>
        <div class="form-group col-md-3">
            <label for="country">Country:</label>
            <input class="form-control" placeholder="" autocomplete="off" name="country" type="text" id="country">
        </div>
               
        </div>
                
        <input class="btn btn-info pull-right" type="submit" value="Save">
    </form>
    </div>
</div>
        </div>
    </div>
@stop

@section('footer_scripts')
    <script>
        $(".delete").click(function(){
            return confirm("Are you sure to delete this item?");
        });
    </script>
@stop