<style>
     a.dt-button {
         color: #fff;
         background-color: #5bc0de;
         border-color: #46b8da;
         display: inline-block;
         padding: 6px 12px;
         margin-bottom: 0;
         font-size: 14px;
         font-weight: normal;
         line-height: 1.428571429;
         text-align: center;
         white-space: nowrap;
         vertical-align: middle;
         cursor: pointer;
         background-image: none;
         border: 1px solid transparent;
         border-radius: 4px;
         -webkit-user-select: none;
         -moz-user-select: none;
         -ms-user-select: none;
         -o-user-select: none;
         user-select: none;
     }
    button.dt-button:hover:not(.disabled), div.dt-button:hover:not(.disabled), a.dt-button:hover:not(.disabled),
    button.dt-button:focus:not(.disabled), div.dt-button:focus:not(.disabled), a.dt-button:focus:not(.disabled) {
        border: 1px solid #65c0de;
        background-color: transparent;
        background-image: none;
        color: #65c0de;
    }

</style>
<div class="panel panel-info">
    <div class="panel-heading">
        <h3 class="panel-title bariol-thin"><i
                    class="fa fa-user"></i> {!! $request->all() ? 'Search results:' : 'Agency' !!}</h3>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-12 table-responsive">
                @if(count($agency)!=0)
                    <div class="table-responsive inventory__table">
                        <table class="display nowrap table table-hover table-bordered" id="agency_table">
                            <thead>
                            <tr>
                                <th>Agency Name</th>
                                <th >Person Name</th>
                                <th >Designation</th>
                                <th >Mobile No</th>
                                <th >Email</th>
                                <th >Address</th>
                                <th >PIN</th>
                                <th >City</th>
                                <th >State</th>
                                <th >Country</th>
                                <th style="background-color: #292d2e;color: #fff;">Operations</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($agency as $key)
                                <tr>
                                    <td>{!! $key->name !!}</td>
                                    <td >{!! $key->person1 !!}</td>
                                    <td >{!! $key->designation1 !!}</td>
                                    <td >{!! $key->contact1 !!}</td>
                                    <td >{!! $key->email1 !!}</td>
                                    <td >{!! $key->address1 !!}</td>
                                    <td >{!! $key->pin !!}</td>
                                    <td >{!! $key->city !!}</td>
                                    <td >{!! $key->state !!}</td>
                                    <td >{!! $key->country !!}</td>
                                    <td>
                                        <a href="{!! URL::route('agency.edit', ['id' => $key->id]) !!}"><i
                                                    class="fa fa-pencil-square-o fa-2x"></i></a>
                                        <a href="{!! URL::route('agency.delete',['id' => $key->id, '_token' => csrf_token()]) !!}"
                                           class="margin-left-5 delete"><i class="fa fa-trash-o fa-2x"></i></a>
                                    </td>
                                </tr>
                            </tbody>
                            @endforeach
                        </table>
                    </div>
                    {{--<div class="paginator">
                        {!! $agency->appends($request->except(['page']) )->render() !!}
                    </div>--}}
                @else
                    <span class="text-warning"><h5>No results found.</h5></span>
                @endif
            </div>
        </div>
    </div>
</div>
