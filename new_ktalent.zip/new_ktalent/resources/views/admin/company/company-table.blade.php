<style>
    a.dt-button {
        color: #fff;
        background-color: #5bc0de;
        border-color: #46b8da;
        display: inline-block;
        padding: 6px 12px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.428571429;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        cursor: pointer;
        background-image: none;
        border: 1px solid transparent;
        border-radius: 4px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        -o-user-select: none;
        user-select: none;
    }

    button.dt-button:hover:not(.disabled), div.dt-button:hover:not(.disabled), a.dt-button:hover:not(.disabled),
    button.dt-button:focus:not(.disabled), div.dt-button:focus:not(.disabled), a.dt-button:focus:not(.disabled) {
        border: 1px solid #65c0de;
        background-color: transparent;
        background-image: none;
        color: #65c0de;
    }

</style>
<div class="panel panel-info">
    <div class="panel-heading">
        <h3 class="panel-title bariol-thin"><i
                    class="fa fa-user"></i> {!! $request->all() ? 'Search results:' : 'Company' !!}</h3>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-12 table-responsive">
                @if(count($company)!=0)
                    <div class="table-responsive inventory__table">
                        <table class="display nowrap table table-hover table-bordered" id="company_table">
                            <thead>
                            <tr>
                                <th>Business Name</th>
                                <th>Contact Person</th>
                                <th>Mobile Number</th>
                                <th>E Mail id</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>District</th>
                                <th>State</th>
                                <th>Country</th>
                                <th>Brand Name</th>
                                <th>Legel Identity</th>
                                <th>Nature Of Business</th>
                                <th style="background-color: #292d2e;color: #fff;">Operations</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($company as $key)
                                <tr>
                                    <td>{!! $key->business_name !!}</td>
                                    <td>{!! $key->contact_person !!}</td>
                                    <td>{!! $key->mobile_no !!}</td>
                                    <td>{!! $key->email_id !!}</td>
                                    <td>{!! $key->address !!}</td>
                                    <td>{!! $key->city !!}</td>
                                    <td>{!! $key->district !!}</td>
                                    <td>{!! $key->state !!}</td>
                                    <td>{!! $key->country !!}</td>
                                    <td>{!! $key->brand_name !!}</td>
                                    <td>{!! $key->legal_identity !!}</td>
                                    <td>{!! $key->nature_business !!}</td>
                                    <td>
                                        <a href="{!! URL::route('company.edit', ['id' => $key->id]) !!}"><i
                                                    class="fa fa-pencil-square-o fa-2x"></i></a>
                                        {!! Form::open(['method' => 'DELETE','route' => ['company.destroy', $key->id],'style'=>'display:inline']) !!}
                                        {!! Form::button('<i class="fa fa-trash-o fa-2x"></i>', ['type' => 'submit', 'class' => 'btn btn-sm' ,'style'=>'padding: 0px 08px;background: transparent; display: table-cell;vertical-align: top;color: #5bc0de;'] ) !!}
                                        {!! Form::close() !!}
                                    </td>
                                </tr>
                            </tbody>
                            @endforeach
                        </table>
                    </div>
                    {{--<div class="paginator">
                        {!! $agency->appends($request->except(['page']) )->render() !!}
                    </div>--}}
                @else
                    <span class="text-warning"><h5>No results found.</h5></span>
                @endif
            </div>
        </div>
    </div>
</div>
