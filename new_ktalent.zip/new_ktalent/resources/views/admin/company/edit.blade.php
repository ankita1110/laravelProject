@extends('layouts.app')

@section('title')
    Admin area: Add Company
@stop

@section('content')
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid margin-right-15">
        <div class="navbar-header">
            <a class="navbar-brand bariol-thin" href="#"></a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-main-menu">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="nav-main-menu">
            <ul class="nav navbar-nav">
                <li><a href="{{ url('/home') }}">Dashboard</a></li>
                <li><a href="{{ url('/agency/list') }}">Agency</a></li>
                <li><a href="{{ url('/job') }}">Job</a></li>
                <li><a href="{{ url('/company') }}">Company</a></li>
                <li><a href="{{ url('/applicant') }}">Applicant</a></li>
                
            </ul>
            <div class="navbar-nav nav navbar-right">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
                        <img src="" width="30">
                        <span id="nav-email">{{ Auth::user()->email }}</span><i class="fa fa-caret-down"></i>
                    </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                            </li>
                        </ul>
                </li>
            </div><!-- nav-right -->
        </div><!--/.nav-collapse -->
    </div>
</div>
    <div class="row">
        <div class="col-sm-3 col-md-2 col-xs-12 sidebar">
            <ul class="nav nav-sidebar">
                <li class="active"><a href="URL('/company')"><i class="fa fa-tachometer"></i>Company List</a></li>
                <li><a href="{{URL('/company/create')}}"><i class="fa fa-tachometer"></i>Add New</a></li>
                <li><a href="{{URL('/company/invite')}}"><i class="fa fa-tachometer">Send Invitation</i></a></li>
            </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i>Company</h3>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-xs-12">
                        <h4>Company data</h4>
                    <form method="POST" action="{!! URL::route('company.update', ['id' => $company->id]) !!}">
                        <input name="_method" type="hidden" value="PATCH">
                        {{ csrf_field() }}
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                            <div class="form-group col-md-6">
                                <label for="business_name">Business Name  :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="business_name" type="text" value="<?php echo isset($company->business_name)? $company->business_name:''?>" id="business_name">
                            </div>
                            <!-- contact_person text field -->
                            <div class="form-group col-md-6">
                                <label for="contact_person">Contact Person :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="contact_person" type="text" value="<?php echo isset($company->contact_person)? $company->contact_person:''?>" id="contact_person">
                            </div>
                            <!-- mobile_no text field -->
                            <div class="form-group col-md-6">
                                <label for="mobile_no">Mobile Number :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="mobile_no" type="text" value="<?php echo isset($company->mobile_no)? $company->mobile_no:''?>" id="mobile_no">
                            </div>
                            <!-- email_id text field -->
                            <div class="form-group col-md-6">
                                <label for="email_id">E Mail id :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="email_id" type="text" value="<?php echo isset($company->email_id)? $company->email_id:''?>" id="email_id">
                            </div>
                            <!-- address text field -->
                            <div class="form-group col-md-6">
                                <label for="address">Address :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="address" type="text" value="<?php echo isset($company->address)? $company->address:''?>" id="address">
                            </div>
                            <!-- city text field -->
                            <div class="form-group col-md-6">
                                <label for="city">City :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="city" type="text" value="<?php echo isset($company->city)? $company->city:''?>" id="city">
                            </div>
                        </div>
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                            <!-- district text field -->
                            <div class="form-group col-md-6">
                                <label for="district">District :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="district" type="text" value="<?php echo isset($company->district)? $company->district:''?>" id="district">
                            </div>
                            <!-- state text field -->
                            <div class="form-group col-md-6">
                                <label for="state">State :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="state" type="text" value="<?php echo isset($company->state)? $company->state:''?>" id="state">
                            </div>
                            <!-- country text field -->
                            <div class="form-group col-md-6">
                                <label for="country">Country :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="country" type="text" value="<?php echo isset($company->country)? $company->country:''?>" id="country">
                            </div>
                            <!-- brand_name text field -->
                            <div class="form-group col-md-6">
                                <label for="brand_name">Brand Name :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="brand_name" type="text" value="<?php echo isset($company->brand_name)? $company->brand_name:''?>" id="brand_name">
                            </div>
                            <!-- legal_identity text field -->
                            <div class="form-group col-md-6">
                                <label for="legal_identity">Legal Identity :</label>
                                <input class="form-control" placeholder="" autocomplete="off" name="legal_identity" type="text" value="<?php echo isset($company->legal_identity)? $company->legal_identity:''?>" id="legal_identity">
                            </div>
                            <!-- nature_business select field -->
                            <div class="form-group col-md-6">
                                <label for="nature_business">Nature Of Business :</label>
                                <select class="form-control" id="nature_business" name="nature_business">
                                    <?php 
                                        if($company->nature_business == 'Manufacturers'){
                                            ?>
                                                <option value="Manufacturers" selected="selected">Manufacturers</option>
                                                <option value="Services">Services</option>
                                                <option value="Marketing">Marketing</option>            
                                            <?php
                                        }
                                        else if($company->nature_business == 'Services'){
                                            ?>
                                                <option value="Manufacturers">Manufacturers</option>
                                                <option value="Services" selected="selected">Services</option>
                                                <option value="Marketing">Marketing</option>
                                            <?php
                                        }
                                        else if($company->nature_business == 'Marketing'){
                                            ?>
                                                <option value="Manufacturers">Manufacturers</option>
                                                <option value="Services">Services</option>
                                                <option value="Marketing" selected="selected">Marketing</option>
                                            <?php
                                        }
                                    ?>
                                    
                                </select>
                            </div>
                        </div>
                        <input class="btn btn-info pull-right " type="submit" value="Save">
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

@section('footer_scripts')
    <script>
        $(".delete").click(function(){
            return confirm("Are you sure to delete this item?");
        });
    </script>
@stop