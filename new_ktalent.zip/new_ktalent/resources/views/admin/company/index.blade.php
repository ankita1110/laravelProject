@extends('layouts.app')

@section('title')
    Admin area: Job list
@stop

@section('content')
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid margin-right-15">
        <div class="navbar-header">
            <a class="navbar-brand bariol-thin" href="#"></a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-main-menu">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="nav-main-menu">
            <ul class="nav navbar-nav">
                <li><a href="{{ url('/home') }}">Dashboard</a></li>
                <li><a href="{{ url('/agency/list') }}">Agency</a></li>
                <li><a href="{{ url('/job') }}">Job</a></li>
                <li><a href="{{ url('/company') }}">Company</a></li>
                <li><a href="{{ url('/applicant') }}">Applicant</a></li>
                
            </ul>
            <div class="navbar-nav nav navbar-right">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
                        <img src="" width="30">
                        <span id="nav-email">{{ Auth::user()->email }}</span><i class="fa fa-caret-down"></i>
                    </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                            </li>
                        </ul>
                </li>
            </div><!-- nav-right -->
        </div><!--/.nav-collapse -->
    </div>
</div>

    <div class="row">
        <div class="col-sm-3 col-md-2 col-xs-12 sidebar">
                <ul class="nav nav-sidebar">
                    <li class="active"><a href="{{ URL('/company') }}"><i class="fa fa-tachometer"></i>Company List</a></li>
                    <li><a href="{{URL('/company/create')}}"><i class="fa fa-tachometer"></i>Add New</a></li>
                    <li><a href="{{URL('/company/invite')}}"><i class="fa fa-tachometer">Send Invitation</i></a></li>
                </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h3 class="panel-title bariol-thin"><i
                                    class="fa fa-user"></i> {!! $request->all() ? 'Search results:' : 'Company' !!}</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12 table-responsive">
                                @if(count($company)!=0)
                                    <div class="table-responsive inventory__table">
                                        <table class="display nowrap table table-hover table-bordered" id="company_table">
                                            <thead>
                                            <tr>
                                                <th>Business Name</th>
                                                <th>Contact Person</th>
                                                <th>Mobile Number</th>
                                                <th>E Mail id</th>
                                                <th>Address</th>
                                                <th>City</th>
                                                <th>District</th>
                                                <th>State</th>
                                                <th>Country</th>
                                                <th>Brand Name</th>
                                                <th>Legel Identity</th>
                                                <th>Nature Of Business</th>
                                                <th style="background-color: #292d2e;color: #fff;">Operations</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($company as $key)
                                                <tr>
                                                    <td>{!! $key->business_name !!}</td>
                                                    <td>{!! $key->contact_person !!}</td>
                                                    <td>{!! $key->mobile_no !!}</td>
                                                    <td>{!! $key->email_id !!}</td>
                                                    <td>{!! $key->address !!}</td>
                                                    <td>{!! $key->city !!}</td>
                                                    <td>{!! $key->district !!}</td>
                                                    <td>{!! $key->state !!}</td>
                                                    <td>{!! $key->country !!}</td>
                                                    <td>{!! $key->brand_name !!}</td>
                                                    <td>{!! $key->legal_identity !!}</td>
                                                    <td>{!! $key->nature_business !!}</td>
                                                    <td>
                                                        <a href="{!! URL::route('company.edit', ['id' => $key->id]) !!}">
                                                            <i class="fa fa-pencil-square-o fa-2x"></i>
                                                        </a>
                                                        <form method="POST" action="{!! URL::route('company.destroy', ['id' => $key->id]) !!}">
                                                            <input name="_method" type="hidden" value="DELETE">
                                                            {{ csrf_field() }}
                                                            <button type="submit" class="btn btn-sm" style="padding: 0px 08px;background: transparent;display: table-cell;vertical-align: top;color: #5bc0de;">
                                                                <i class="fa fa-trash-o fa-2x"></i></button>
                                                        </form>            
                                                        
                                                    </td>
                                                </tr>
                                            </tbody>
                                            @endforeach
                                        </table>
                                    </div>
                                @else
                                    <span class="text-warning"><h5>No results found.</h5></span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
@stop

@section('footer_scripts')
    <script>
        $(".delete").click(function(){
            return confirm("Are you sure to delete this item?");
        });
        $(document).ready(function () {
            $('#company_table').DataTable({
                fixedColumns: {
                    rightColumns: 1,
                    leftColumns: 0
                },
                "scrollX": true,
                destroy: true,
                "paging": true,
                dom: 'Bfrtip',
                buttons: [
                    {
                        text: 'Add New',
                        action: function (e, dt, node, config) {
                            var url = '/company/create';
                            window.location.href = url;
                        }
                    }
                ]
            });
        });
    </script>
@stop