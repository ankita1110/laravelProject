<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Agency Invitation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/bootstrap.min.css') !!}
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/style.css') !!}
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/baselayout.css') !!}
    {!! HTML::style('packages/jacopo/laravel-authentication-acl/css/fonts.css') !!}
    {!! HTML::style('//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css') !!}
    {!! HTML::style('//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css') !!}
    {!! HTML::style('//cdn.datatables.net/fixedcolumns/3.2.3/css/fixedColumns.dataTables.min.css') !!}
    {!! HTML::style('//cdn.datatables.net/buttons/1.4.2/css/buttons.dataTables.min.css') !!}
</head>
<body>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="col-xs-12 main">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-md-12">
                                    <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i> Create Agency</h3>
                                </div>
                            </div>
                        </div>
                        <div class="panel-body">
                            <div class="col-md-12 col-xs-12">
                                <h4>Company data</h4>
                            {!! Form::open(array('route' => 'company.storeInvite','method'=>'POST')) !!}
                            <!-- business_name text field -->
                                <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                    <div class="form-group col-md-6">
                                        {!! Form::label('business_name','Business Name  :') !!}
                                        {!! Form::text('business_name', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- contact_person text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('contact_person','Contact Person :') !!}
                                        {!! Form::text('contact_person', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- mobile_no text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('mobile_no','Mobile Number :') !!}
                                        {!! Form::text('mobile_no', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- email_id text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('email_id','E Mail id :') !!}
                                        {!! Form::text('email_id', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- address text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('address','Address :') !!}
                                        {!! Form::text('address', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- city text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('city','City :') !!}
                                        {!! Form::text('city', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                </div>
                                <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                                    <!-- district text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('district','District :') !!}
                                        {!! Form::text('district', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- state text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('state','State :') !!}
                                        {!! Form::text('state', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- country text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('country','Country :') !!}
                                        {!! Form::text('country', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- brand_name text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('brand_name','Brand Name :') !!}
                                        {!! Form::text('brand_name', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- legal_identity text field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('legal_identity','Legal Identity :') !!}
                                        {!! Form::text('legal_identity', null, ['class' => 'form-control', 'placeholder' => '', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <!-- nature_business select field -->
                                    <div class="form-group col-md-6">
                                        {!! Form::label('nature_business','Nature Of Business :') !!}
                                        {!! Form::select('nature_business', ["Manufacturers" => "Manufacturers", "Services" => "Services", "Marketing" => "Marketing"],null,["class"=> "form-control"] ) !!}
                                    </div>
                                </div>
                            </div>
                            {!! Form::submit('Save', array("class"=>"btn btn-info pull-right ")) !!}
                            {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{!! HTML::script('packages/jacopo/laravel-authentication-acl/js/vendor/jquery-1.10.2.min.js') !!}
{!! HTML::script('packages/jacopo/laravel-authentication-acl/js/vendor/bootstrap.min.js') !!}
{!! HTML::script('//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js') !!}
{!! HTML::script('//cdn.datatables.net/fixedcolumns/3.2.3/js/dataTables.fixedColumns.min.js') !!}
{!! HTML::script('//cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js') !!}
</body>
</html>