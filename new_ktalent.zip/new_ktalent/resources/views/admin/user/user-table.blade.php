<style>
    a.dt-button {
        color: #fff;
        background-color: #5bc0de;
        border-color: #46b8da;
        display: inline-block;
        padding: 6px 12px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.428571429;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        cursor: pointer;
        background-image: none;
        border: 1px solid transparent;
        border-radius: 4px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        -o-user-select: none;
        user-select: none;
    }

    button.dt-button:hover:not(.disabled), div.dt-button:hover:not(.disabled), a.dt-button:hover:not(.disabled),
    button.dt-button:focus:not(.disabled), div.dt-button:focus:not(.disabled), a.dt-button:focus:not(.disabled) {
        border: 1px solid #65c0de;
        background-color: transparent;
        background-image: none;
        color: #65c0de;
    }

</style>
<div class="panel panel-info">
    <div class="panel-heading">
        <h3 class="panel-title bariol-thin"><i
                    class="fa fa-user"></i> {!! $request->all() ? 'Search results:' : 'Users' !!}</h3>
    </div>
    <div class="panel-body">
        
        <div class="row">
            <div class="col-md-12">
                @if(! $users->isEmpty() )
                    <div class="table-responsive inventory__table">
                        <table class="display nowrap table table-hover table-bordered" id="user_table">
                            <thead>
                            <tr>
                                <th>Email</th>
                                <th>First name</th>
                                <th>Last name</th>
                                <th>Active</th>
                                <th>Last login</th>
                                <th style="background-color: #292d2e;color: #fff;">Operations</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($users as $user)
                                <tr>
                                    <td>{!! $user->email !!}</td>
                                    <td>{!! $user->first_name !!}</td>
                                    <td>{!! $user->last_name !!}</td>
                                    <td>{!! $user->activated ? '<i class="fa fa-circle green"></i>' : '<i class="fa fa-circle-o red"></i>' !!}</td>
                                    <td>{!! $user->last_login ? $user->last_login : 'not logged yet.' !!}</td>
                                    <td>
                                        @if(! $user->protected)
                                            <a href="{!! URL::route('users.edit', ['id' => $user->id]) !!}"><i
                                                        class="fa fa-pencil-square-o fa-2x"></i></a>
                                            <a href="{!! URL::route('users.delete',['id' => $user->id, '_token' => csrf_token()]) !!}"
                                               class="margin-left-5 delete"><i class="fa fa-trash-o fa-2x"></i></a>
                                        @else
                                            <i class="fa fa-times fa-2x light-blue"></i>
                                            <i class="fa fa-times fa-2x margin-left-12 light-blue"></i>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="paginator">
                        {!! $users->appends($request->except(['page']) )->render() !!}
                    </div>
                @else
                    <span class="text-warning"><h5>No results found.</h5></span>
                @endif
            </div>
        </div>
    </div>
</div>
