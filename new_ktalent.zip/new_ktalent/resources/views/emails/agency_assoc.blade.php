<h1>Hi</h1>

<p>Please check your Request with Your login Details</p>

<p>Here is the URL <a href="{{ $com_url }}">{{ $com_url }}</a></p>

<h3>Thanks</h3>