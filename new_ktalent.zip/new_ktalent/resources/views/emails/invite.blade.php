@section('content')
    <tr>
        <td class="title">
            Welcome {{$user}}
        </td>
    </tr>
    <tr>
        <td width="100%" height="10"></td>
    </tr>
    <tr>
        <td class="paragraph">
            Congratulations, You have received an invitation, Please click sign up button to register
        </td>
    </tr>
    <tr>
        <td width="100%" height="25"></td>
    </tr>
    <tr>
        <td>
            
        </td>
    </tr>
    <tr>
        <td width="100%" height="25"></td>
    </tr>
    

@stop