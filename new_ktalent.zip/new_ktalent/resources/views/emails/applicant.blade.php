<h1>Hi, {{ $f_name }}</h1>
<p>Thank You for Applicant Regisration</p>
<p>Please click here for login <a href="{{$home_url}}">{{ $home_url }}</a></p>

<h3>Please find your account details below:</h3>
<ul>
	<li>Username: {{ $name }}</li>
	<li>Password: {{ $password }}</li>
</ul>