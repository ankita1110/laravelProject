<h1>Hi, {{ $name }}</h1>
<p>Thank You for Company Regisration</p>

<p>Please click here for login <a href="{{$link}}">{{ $link }}</a></p>

<h3>Please find your account details below:</h3>
<ul>
	<li>Username: {{ $username }}</li>
	<li>Password: {{ $password }}</li>
</ul>