@extends('layouts.app')

@section('content')
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid margin-right-15">
        <div class="navbar-header">
            <a class="navbar-brand bariol-thin" href="#"></a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-taret="#nav-main-menu">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="nav-main-menu">
            <ul class="nav navbar-nav">
                <li><a href="{{ url('/home') }}">Dashboard</a></li>
                <li><a href="{{ url('/post_job') }}">Post Job</a></li>
                <li><a href="{{ url('/list_job') }}">List Job</a></li>
                <li><a href="{{ url('/company_services') }}">Request for Service</a></li>
                <li><a href="{{ url('/find_agency') }}">Find Agency</a></li>
            </ul>
            <div class="navbar-nav nav navbar-right">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
                        <img src="" width="30">
                        <span id="nav-email">{{ Auth::user()->email }}</span> <i class="fa fa-caret-down"></i>
                    </a>
	                    <ul class="dropdown-menu">
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                            </li>
	                    </ul>
                </li>
            </div><!-- nav-right -->
        </div><!--/.nav-collapse -->
    </div>
</div>
<div class="container-fluid">
	<div class="row-fluid">
		<div class="col-sm-3 col-md-2 col-xs-12 sidebar">
		    <ul class="nav nav-sidebar">
            <li class="active"><a href="{{ URL('/home') }}"><i class="fa fa-tachometer"></i> Dashboard</a></li>
		    <li><a href="{{ URL('/post_job') }}"><i class="fa fa-tachometer"></i> Post Job</a></li>
            <li><a href="{{ URL('/list_job') }}"><i class="fa fa-tachometer"></i>List Job</a></li>
		</ul>
		</div>
		<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i>Edit Job</h3>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-xs-12">
                        <h4>Job data</h4>
                    <form method="POST" action="{{ URL::route('company.job.update',['id' => $job_edit->id]) }}">
                    {{ csrf_field() }} 
                    <input type="hidden" name="author_id" value="{{ Auth::user()->email }}">
                        <!-- designation name text field -->
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                            <div class="form-group col-md-6">
                                <label for="designation">Designation : </label>
                                <input type="text" name="designation" class="form-control" placeholder="" autocomplete="off" value="{{ $job_edit->designation }}">
                            </div>
                            <!-- department name text field -->
                            <div class="form-group col-md-6">
                                <label for="department">Department : </label>
                                <input type="text" name="department" class="form-control" placeholder="" autocomplete="off" value="{{ $job_edit->department }}">
                            </div>
                            <!-- salary name text field -->
                            <div class="form-group col-md-6">
                                <label for="salary">Salary : </label>
                                <input type="text" name="salary" class="form-control" placeholder="" autocomplete="off" value="{{ $job_edit->salary }}">
                            </div>
                            <!-- experience name text field -->
                            <div class="form-group col-md-6">
                                <label for="experience">Experience :*</label>
                                <input type="text" name="experience" class="form-control" required="required" placeholder="" autocomplete="off" value="{{ $job_edit->experience }}">
                            </div>
                            <!-- education name text field -->
                            <div class="form-group col-md-6">
                                <label for="education">Education :*</label>
                                <input type="text" name="education" class="form-control" placeholder="" autocomplete="off" required="required" value="{{ $job_edit->education }}">
                            </div>
                            <!-- technical_education name text field -->
                            <div class="form-group col-md-6">
                                <label for="technical_education">Technical Education :*</label>
                                <input type="text" name="technical_education" class="form-control" placeholder="" autocomplete="off" required="required" value="{{ $job_edit->technical_education }}">
                            </div>
                        </div>
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                            <!-- location name text field -->
                            <div class="form-group col-md-6">
                                <label for="location">Location :</label>
                                <input type="text" name="location" class="form-control" placeholder="" autocomplete="off" value="{{ $job_edit->location }}">
                            </div>
                            <!-- key_jobs_role name text field -->
                            <div class="form-group col-md-6">
                                <label for="key_jobs_role">Key Jobs Role :</label>
                                <input type="text" name="key_jobs_role" class="form-control" placeholder="" autocomplete="off" value="{{ $job_edit->key_jobs_role }}">
                            </div>
                            <!-- desired_skills name text field -->
                            <div class="form-group col-md-6">
                                <label for="desired_skills">Desired Skills :</label>
                                <input type="text" name="desired_skills" class="form-control" placeholder="" autocomplete="off" value="{{ $job_edit->desired_skills }}">
                            </div>
                            <!-- other_benefits name text field -->
                            <div class="form-group col-md-6">
                                <label for="other_benefits">Other Benefits (Apart from Salary ) :</label>
                                <input type="text" name="other_benefits" class="form-control" placeholder="" autocomplete="off" value="{{ $job_edit->other_benefits }}">
                            </div>
                            <!-- types_job name select field -->
                            <div class="form-group col-md-6">
                                <label for="types_job">Type of Job :</label>
                                <select class="form-control" name="types_job">
                                @if($job_edit->types_job == 'Permanent')
                                    <option value="Permanent" selected="selected">Permanent</option>
                                    <option value="Temporary">Temporary</option>
                                    <option value="Contract">Contract</option>
                                @elseif($job_edit->types_job == 'Temporary')        
                                    <option value="Permanent">Permanent</option>
                                    <option value="Temporary" selected="selected">Temporary</option>
                                    <option value="Contract">Contract</option>
                                @elseif($job_edit->types_job == 'Contract')
                                    <option value="Permanent">Permanent</option>
                                    <option value="Temporary">Temporary</option>
                                    <option value="Contract" selected="selected">Contract</option>
                                @endif
                                </select>
                            </div>
                        </div>
                    <input class="btn btn-info pull-right " type="submit" value="Save">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection