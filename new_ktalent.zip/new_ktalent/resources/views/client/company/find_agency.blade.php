@extends('layouts.app')

@section('content')
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid margin-right-15">
        <div class="navbar-header">
            <a class="navbar-brand bariol-thin" href="#"></a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-main-menu">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="nav-main-menu">
            <ul class="nav navbar-nav">
                <li><a href="{{ url('/home') }}">Dashboard</a></li>
                <li><a href="{{ url('/post_job') }}">Post Job</a></li>
                <li><a href="{{ url('/list_job') }}">Job List</a></li>
                <li><a href="{{ url('/company_services') }}">Request for Service</a></li>
                <li><a href="{{ url('/find_agency') }}">Find Agency</a></li>
            </ul>
            <div class="navbar-nav nav navbar-right">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
                        <img src="" width="30">
                        <span id="nav-email">{{ Auth::user()->email }}</span> <i class="fa fa-caret-down"></i>
                    </a>
	                    <ul class="dropdown-menu">
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                            </li>
	                    </ul>
                </li>
            </div><!-- nav-right -->
        </div><!--/.nav-collapse -->
    </div>
</div>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="col-sm-3 col-md-2 col-xs-12 sidebar">
            <ul class="nav nav-sidebar">
                <li class="active"><a href="{{URL('/')}}"><i class="fa fa-tachometer"></i> Dashboard</a></li>
            </ul>
        </div>

        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
            @if(session()->has('message'))
                <div class="alert alert-success">{{session()->get('message')}}</div>
            @endif
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i> Find Agency</h3>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-xs-12">
                        <h4> Find Agency</h4>
                    <form method="POST" action="{{URL ('/find_agency') }}">
                    {{ csrf_field() }} 
                    <input type="hidden" name="author_id" value="{{ Auth::user()->email }}">
                        <!-- designation name text field -->
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                            <div class="form-group col-md-6">
                                <label for="id_search">Search by ID :</label>
                                <input type="number" name="id_search" class="form-control id_data" placeholder="" autocomplete="off">
                            </div>
                            <!-- technical_education name text field -->
                            <div class="form-group col-md-6">
                                <label for="search_by_name">Search by Name :</label>
                                <input type="text" name="search_by_name" class="form-control name_data" placeholder="" autocomplete="off">
                            </div>
                        </div>
                        <div class="parent-warpper col-md-12" style="padding: 0px 0;border-bottom: 1px solid #ddd;margin: 10px 0;">
                            <!-- location name text field -->
                            <div class="form-group col-md-6">
                                <label for="location">Search by City :</label>
                                <input type="text" name="location" class="form-control city_data" placeholder="" autocomplete="off">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="search_by_email">Search by Email :</label>
                                <input type="text" name="search_by_email" class="form-control email_data" placeholder="" autocomplete="off">
                            </div>
                        </div>
                    <input class="btn btn-info pull-right btn-blank" type="submit" value="Search">
                        </div>
                    </form>
                </div>
            </div>
    </div>

<div class="container-fluid">
    <div class="row-fluid">
@if(isset($agency_data))
<?php if(count($agency_data) != 0){?>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
               <div class="panel panel-info">
                    <div class="panel-heading">
                        <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i> Agency Listing</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12 table-responsive">
                                <?php if(!empty($agency_data)) { ?>
                                    <div class="table-responsive inventory__table">
                                        <table class="display nowrap table table-hover table-bordered" id="job_table">
                                            <thead>
                                            <tr>
                                                <th>Agency Name</th>
                                                <th>Contact Person</th>
                                                <th>Contact Number</th>
                                                <th>Agency Email</th>
                                                <th>City</th>
                                                <th style="background-color: #292d2e;color: #fff;">Operations</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($agency_data as $value)
                                                <tr>
                                                    <td>{{ $value->name }}</td>
                                                    <td>{{ $value->person1 }}</td>
                                                    <td>{{ $value->contact1 }}</td>
                                                    <td>{{ $value->email1 }}</td>
                                                    <td>{{ $value->city }}</td>
                                                    <td>
                                                        <form method="POST" action="{{ URL::route('company.invite_agency', ['id' => $value->id]) }}" style="display: inline;">
                                                            {{ csrf_field() }}
                                                            <button type="submit" class="btn btn-primary">Send Invitation</button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            @endforeach        
                                            
                                        </table>
                                    </div>
                                <?php }else{ ?>
                                    <span class="text-warning"><h5>No results found.</h5></span>
                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
          </div>
<?php }else{
    ?>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i> Agency Listing</h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <span class="text-warning col-md-6"><h5>No results found.</h5></span>
                    </div>
                </div>
            </div>
        </div>
    <?php
}?>          
@else
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
    <div class="panel panel-info">
        <div class="panel-heading">
            <h3 class="panel-title bariol-thin"><i class="fa fa-user"></i> Agency Listing</h3>
        </div>
        <div class="panel-body">
            <div class="row">
                <span class="text-warning col-md-6"><h5>No results found.</h5></span>
            </div>
        </div>
    </div>
</div>
</div>
@endif

<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('.btn-blank').click(function(){
            var city=jQuery('.city_data').val();
            var id=jQuery('.id_data').val();
            var name=jQuery('.name_data').val();
            var email=jQuery('.email_data').val();

            if((name || city || id || email) == ''){
                alert('Please fill at least one of field');
                return false;
            }

        })
    })
</script>

@endsection