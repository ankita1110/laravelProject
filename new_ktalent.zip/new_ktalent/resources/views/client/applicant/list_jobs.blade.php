@extends('layouts.app')

@section('content')
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid margin-right-15">
        <div class="navbar-header">
            <a class="navbar-brand bariol-thin" href="#"></a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-main-menu">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="nav-main-menu">
            <ul class="nav navbar-nav">
                <li><a href="{{ url('/home') }}">Dashboard</a></li>
                <li><a href="{{ url('/apply_job') }}">Apply for Job</a></li>
            </ul>
            <div class="navbar-nav nav navbar-right">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
                        <img src="" width="30">
                        <span id="nav-email">{{ Auth::user()->email }}</span> <i class="fa fa-caret-down"></i>
                    </a>
	                    <ul class="dropdown-menu">
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                            </li>
	                    </ul>
                </li>
            </div><!-- nav-right -->
        </div><!--/.nav-collapse -->
    </div>
</div>
<div class="container-fluid">
	<div class="row-fluid">
		<div class="col-sm-3 col-md-2 col-xs-12 sidebar">
		    <ul class="nav nav-sidebar">
            <li class="active"><a href="{{ URL('/') }}"><i class="fa fa-tachometer"></i> Dashboard</a></li>
		</ul>
		</div>
		<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
			<div class="row">
			    <div class="col-md-12 col-sm-12 col-xs-12">
			        <h3><i class="fa fa-dashboard"></i> Job List</h3>
			        <hr/>
			    </div>
            @foreach( $display_job as $all_jobs )
            <div class="panel-group">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a class="job_title_click" href="">Job Title - {{ $all_jobs->designation }}</a>
                        </h4>
                    </div>
                    <div class="panel-collapse collapse">
                        <div class="panel-body">
                            <div class="col-md-12">
                                <div class="col-md-5">
                                    <p>=> Department - {{ $all_jobs->department }}</p>
                                    <p>=> Salary - {{ $all_jobs->salary }}</p>
                                    <p>=> Experience - {{ $all_jobs->experience }}</p>
                                    <p>=> Education - {{ $all_jobs->education }}</p>
                                    <p>=> Technical Education - {{ $all_jobs->technical_education }}</p>
                                </div>
                                <div class="col-md-5">
                                    <p>=> Job Location - {{ $all_jobs->location }}</p>
                                    <p>=> Key Job Role - {{ $all_jobs->key_jobs_role }}</p>
                                    <p>=> Top Skills - {{ $all_jobs->desired_skills }}</p>
                                    <p>=> Type of Job - {{ $all_jobs->types_job }}</p>
                                </div>
                                <div class="col-md-2">
                                    <form action="{{ URL('/apply_job') }}" method="POST">
                                        {{ csrf_field() }}
                                        <?php 
                                        $job_val = $all_jobs->apply_auth;
                                        $diff_value = explode(',' , $job_val);
                                        $exist_record = in_array(Auth::user()->id,$diff_value);
                                        
                                        if($exist_record == 0 || $exist_record == NULL){?>
                                            <button class="btn btn-primary">Apply Now</button>
                                        <?php }else if($exist_record == 1){?>    
                                            <div class="btn btn-primary">Already Applied</div> 
                                        <?php }?>
                                        <input type="hidden" name="job_id" value="{{ $all_jobs->id }}">
                                        <input type="hidden" name="apply_auth" value="{{ Auth::user()->id }}">
                                    </form>    
                                </div>
                            </div>
                            
                        </div>    
                    </div>
                </div>
            </div>
            @endforeach
			</div>
		</div>	
	</div>
</div>

<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('.job_title_click').click(function(event){
            event.preventDefault();
            jQuery(this).parent().parent().next().delay(200).toggle();
        })
    })
</script>
@endsection

