@extends('layouts.app')

@section('content')
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid margin-right-15">
        <div class="navbar-header">
            <a class="navbar-brand bariol-thin" href="#"></a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-main-menu">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="nav-main-menu">
            <ul class="nav navbar-nav">
                <li><a href="{{ url('/home') }}">Dashboard</a></li>
                <li><a href="{{ url('/applicant_add') }}">Add Applicant</a></li>
                <li><a href="{{ url('/list_applicant') }}">List Applicant</a></li>
                <li><a href="{{ url('/agency_associate') }}">Request for Associate</a></li>
                <li><a href="{{ url('/find_company') }}">Find Company</a></li>
            </ul>
            <div class="navbar-nav nav navbar-right">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
                        <img src="" width="30">
                        <span id="nav-email">{{ Auth::user()->email }}</span> <i class="fa fa-caret-down"></i>
                    </a>
	                    <ul class="dropdown-menu">
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                            </li>
	                    </ul>
                </li>
            </div><!-- nav-right -->
        </div><!--/.nav-collapse -->
    </div>
</div>
<div class="container-fluid">
	<div class="row-fluid">
		<div class="col-sm-3 col-md-2 col-xs-12 sidebar">
		    <ul class="nav nav-sidebar">
		    <li class="active"><a href=""><i class="fa fa-tachometer"></i> Dashboard</a></li>
		</ul>
		</div>
		<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
           <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title bariol-thin"><i
                                class="fa fa-user"></i> Applicant List</h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12 table-responsive">
                            @if(count($applicant_list)!=0)
                                <div class="table-responsive inventory__table">
                                    <table class="display nowrap table table-hover table-bordered" id="applicant_table">
                                        <thead>
                                        <tr>
                                            <th>Profile</th>
                                            <th>First Name</th>
                                            <th>Middle Name</th>
                                            <th>Last Name</th>
                                            <th>Father/Spouse Name</th>
                                            <th>Mother Name</th>
                                            <th>Mobile Number</th>
                                            <th>Email Id</th>
                                            <th>Address</th>
                                            <th>State</th>
                                            <th>District</th>
                                            <th>Country</th>
                                            <th>Pin</th>
                                            <th>Education</th>
                                            <th>Experience</th>
                                            <th>Hobbies</th>
                                            <th>Reference</th>
                                            <th style="background-color: #292d2e;color: #fff;">Operations</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($applicant_list as $key)
                                            <tr>
                                                <td>
                                                    @if(! empty($key->picture))
                                                        <img src="/app/public/images/applicant/{{ $key->picture }}"
                                                             style="width:80px; height:80px; float:left; border-radius:50%; margin-right:25px;">
                                                    @else
                                                        <img src="/app/public/images/applicant/unknown.jpg"
                                                             style="width:80px; height:80px; float:left; border-radius:50%; margin-right:25px;">
                                                    @endif
                                                </td>
                                                <td>{!! $key->first_name !!}</td>
                                                <td>{!! $key->middle_name !!}</td>
                                                <td>{!! $key->last_name !!}</td>
                                                <td>{!! $key->father_spouse_name !!}</td>
                                                <td>{!! $key->mother_name !!}</td>
                                                <td>{!! $key->mobile_no !!}</td>
                                                <td>{!! $key->email_id !!}</td>
                                                <td>{!! $key->address1 !!}</td>
                                                <td>{!! $key->state !!}</td>
                                                <td>{!! $key->district !!}</td>
                                                <td>{!! $key->country !!}</td>
                                                <td>{!! $key->pin !!}</td>
                                                <td>{!! $key->education !!}</td>
                                                <td>{!! $key->experience !!}</td>
                                                <td>{!! $key->hobbies !!}</td>
                                                <td>{!! $key->reference !!}</td>
                                                <td>
                                                    <a href="{!! URL::route('applicant_ag.edit', ['id' => $key->id]) !!}"><i
                                                                class="fa fa-pencil-square-o fa-2x"></i></a>
                                                    <form method="POST" action="{!! URL::route('applicant_ag.delete', ['id' => $key->id]) !!}" style="display: inline;">
                                                        <input name="_method" type="hidden" value="DELETE">
                                                        {{ csrf_field() }}
                                                        <button type="submit" class="btn btn-sm" style="padding: 0px 08px;background: transparent;display: table-cell;vertical-align: top;color: #5bc0de;"><i class="fa fa-trash-o fa-2x"></i></button>
                                                    </form>
                                                </td>
                                            </tr>
                                        </tbody>
                                        @endforeach
                                    </table>
                                </div>
                            @else
                                <span class="text-warning"><h5>No results found.</h5></span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
