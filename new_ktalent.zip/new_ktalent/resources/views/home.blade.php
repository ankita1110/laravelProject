@extends('layouts.app')

@section('content')
<?php $base_url = URL::to('/'); ?>
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container-fluid margin-right-15">
        <div class="navbar-header">
            <a class="navbar-brand bariol-thin" href="#"></a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-main-menu">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="nav-main-menu">
            <ul class="nav navbar-nav">
                <li><a href="{{ url('/home') }}">Dashboard</a></li>
                <li><a href="{{ url('/agency/list') }}">Agency</a></li>
                <li><a href="{{ url('/job') }}">Job</a></li>
                <li><a href="{{ url('/company') }}">Company</a></li>
                <li><a href="{{ url('/applicant') }}">Applicant</a></li>
                
            </ul>
            <div class="navbar-nav nav navbar-right">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
                        <img src="" width="30">
                        <span id="nav-email">{{ Auth::user()->email }}</span> <i class="fa fa-caret-down"></i>
                    </a>
	                    <ul class="dropdown-menu">
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                            </li>
	                    </ul>
                </li>
            </div><!-- nav-right -->
        </div><!--/.nav-collapse -->
    </div>
</div>
<div class="container-fluid">
	<div class="row-fluid">
		<div class="col-sm-3 col-md-2 col-xs-12 sidebar">
		            <ul class="nav nav-sidebar">
		    <li class="active"><a href=""><i class="fa fa-tachometer"></i> Dashboard</a></li>
		</ul>
		</div>
		<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 col-xs-12 main">
			<div class="row">
			  <div class="col-md-12 col-sm-12 col-xs-12">
			      <h3><i class="fa fa-dashboard"></i> Dashboard</h3>
			      <hr/>
			  </div>
			  <div class="col-md-12 col-sm-12 col-xs-12">
			          <div class="stats-item margin-left-5 margin-bottom-12"><i class="fa fa-user icon-large"></i> <span class="text-large margin-left-15"></span>
			          <br/>Total Teacher</div>
			          <div class="stats-item margin-left-5 margin-bottom-12"><i class="fa fa-unlock-alt icon-large"></i> <span class="text-large margin-left-15"></span>
			              <br/>Total Examiner</div>
			          <div class="stats-item margin-left-5 margin-bottom-12"><i class="fa fa-lock icon-large"></i> <span class="text-large margin-left-15"></span>
			              <br/>Total Students</div>
			  </div>
			</div>
		</div>	
	</div>
</div>

@endsection
