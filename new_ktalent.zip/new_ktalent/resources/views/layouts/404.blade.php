@extends('layouts.app')

@section('title')
	Admin area: dashboard
@stop
@section('content')
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.erroepage{
		    font-size: 130px;
		    font-weight: 300;
		    text-align: center;
		    color: blue;
		}
		.return {
		    color: rgba(255, 255, 255, 0.6);
		    font-weight: 400;
		    letter-spacing: -0.04em;
		    margin: 0;
		}
		@media (min-width: 480px){
			.return {
			    position: absolute;
			    width: 100%;
			    bottom: 30px;
			}
		}
	</style>
	<title>Not Found</title>
</head>
<body>
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
	<div class="container-fluid margin-right-15">
	    <div class="navbar-header">
	        <a class="navbar-brand bariol-thin" href="#"></a>
	        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav-main-menu">
	        <span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        </button>
	    </div>
	    <div class="collapse navbar-collapse" id="nav-main-menu">
	        <ul class="nav navbar-nav">
	            <li class="active"> <a href="">Dashboard</a></li>
	            <li> <a href="{{ url('/select_test_subject') }}">New Test</a></li>
	            <li><a href="{{ url('/show_result') }}">Show Result</a></li>
	        </ul>
	        <div class="navbar-nav nav navbar-right">
	            <li class="dropdown dropdown-user">
	                <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="dropdown-profile">
	                    <img src="" width="30">
	                    <span id="nav-email">{{ Auth::user()->email }}</span> <i class="fa fa-caret-down"></i>
	                </a>
	                  <ul class="dropdown-menu">
	                        <li>
	                            <a href="{{ route('logout') }}"
	                                onclick="event.preventDefault();
	                                document.getElementById('logout-form').submit();">
	                                Logout
	                            </a>
	                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
	                            {{ csrf_field() }}
	                        </form>
	                        </li>
	                  </ul>
	            </li>
	        </div><!-- nav-right -->
	    </div><!--/.nav-collapse -->
	</div>
</div>
	<h1 class="erroepage" style="font-size: 130px;font-weight: 300;text-align: center;color: blue;">404</h1>
	<p class="return" style="color: #000;font-weight: 400;letter-spacing: 0.04em;margin: 0;text-align: center;">Take me back to <a href="/">Our Test Dashboard</a></p>
</body>
</html>


@endsection