<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Applicant extends Model
{
    protected $table = 'applicant';
    protected $fillable = ["id", "first_name", "middle_name", "last_name", "picture", "father_spouse_name", "mother_name", "mobile_no", "alternate_mobile_no", "email_id", "alternate_email_id","address1", "address2", "address3", "state", "district", "country", "pin", "education", "experience", "hobbies", "reference", "cv", "author_id", "isDeleted"];
}
