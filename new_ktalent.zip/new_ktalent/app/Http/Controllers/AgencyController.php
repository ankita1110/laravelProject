<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use Illuminate\Support\Facades\Input;
use View, Redirect, App, Illuminate\Support\Facades\URL, Config;
use App\Agency;
use App\Job;
use App\Company;
use App\Applicant;
use App\User;
use Auth;
use Hash;
use Mail;


class AgencyController extends Controller
{
    protected $model;

    public function __construct()
    {
        $this->model = new Agency();
    }
    public function index(Request $request)
    {
        $agency = Agency::where("isDeleted", "=", 0)->get();
        $sidebar = array(
            "Agency List" => array('url' => URL::route('agency.list'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('agency.post'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('agency.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        return view('admin.agency.list')->with(["agency" => $agency, "request" => $request,'sidebar_items' => $sidebar]);
    }
    public function create(){
        $sidebar = array(
            "Agency List" => array('url' => URL::route('agency.list'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('agency.post'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('agency.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        return view('admin.agency.create')->with(['sidebar_items' => $sidebar]);;
    }
    public function store(Request $request)
    {
        Agency::create($request->all());
        $home_url = url('/');
        $user=$request->get('email1');
        $ag_name = $request->get('name');
        $password = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
        $user_data = User::create([
            'email' => $request->get('email1'),
            'activated'  => 1,
            'user_type'=>2,
            'password' => Hash::make($password)
        ]);
        $link=array('link' => $home_url.'/company/getInvite');
        //print_r($agencymail);
        Mail::send('emails.agency_reg', ['ag_name'=>$ag_name,'name' => $user,'link'=>$link , 'password' => $password, 'home_url' => $home_url], function($message)use ($user)
        {            
            $send_email = $message->from('devlearnexam@gmail.com')->to($user)->subject('Agency Registration');
        });
        return redirect()->route('agency.list');
    }
    public function edit(Request $request)
    {
        $sidebar = array(
            "Agency List" => array('url' => URL::route('agency.list'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('agency.post'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('agency.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        $agency = Agency::find($request->get('id'));
        return view('admin.agency.edit')->with(["agency" => $agency, "request" => $request,'sidebar_items' => $sidebar]);
    }
    public function update(Request $request,$id)
    {
        $this->validate($request, [
            'name' => 'required',
            'person1'=>'required',
            'contact1'=>'required|min:11|numeric',
            'email1'=>'required|email',
            'city'=>'required',
            'state'=>'required'
        ]);
        Agency::find($id)->update($request->all());
        return redirect()->route('agency.list');
    }
    public function destroy(Request $request)
    {
        Agency::find($request->get('id'))->update(['isDeleted' => 1]);
        return redirect()->route('agency.list');
    }

    public function invite(){
        $sidebar = array(
            "Agency List" => array('url' => URL::route('agency.list'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('agency.post'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('agency.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        return view('admin.agency.invite')->with(['sidebar_items' => $sidebar]);;
    }

    public function getInvite(){
        return view('admin.agency.sendinvite');
    }

    public function sendinvite(Request $request){
        $this->validate($request, [
            'email'=>'required|email',
        ]);
        $user=$request->get('email');
        $token = str_random();
        $link= URL('/').'agency/getInvite';
        $agencymail = app()->make(\Snowfire\Beautymail\Beautymail::class);
        $agencymail->send('emails.invite', ['user' => $user,'link'=>$link], function($message)use ($user)
        {
            $message
                ->from('support.hrbuddy@gmail.com')
                ->to($user)
                ->subject('Your Invitation to HRBUDDY!');
        });
        return redirect()->route('agency.invite');
    }

    public function storeInvite(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'person1'=>'required',
            'contact1'=>'required|min:11|numeric',
            'email1'=>'required|email|unique:agency',
            'city'=>'required',
            'state'=>'required'
        ]);
        Agency::create($request->all());
        return redirect()->route('agency.getInvite');
    }

    public function add_applicant_form(){
        return view('client.agency.add_applicant');
    }
    public function add_applicant_from_agency(Request $request){
        $applicant = new Applicant($request->input()) ;
        $image = Input::file('picture');
        $cv=Input::file('cv');
        if(isset($image)){
            $fileName = date('Y-m-d-H-i-s')."-".$image->getClientOriginalName() ;
            $destinationPath = public_path().'/app/public/images/applicant/' ;
            $image->move($destinationPath,$fileName);
            $applicant->picture = $fileName ;
        }
        if(isset($cv)){
            $cvName = date('Y-m-d-H-i-s')."-".$cv->getClientOriginalName() ;
            $destinationPathcv = public_path().'/app/public/cv/applicant/' ;
            $cv->move($destinationPathcv,$cvName);
            $applicant->cv = $cvName ;
        }
        $applicant->save($request->all());

        $home_url = url('/');
        $user=$request->get('email_id');
        $name = $request->get('first_name');
        $password = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
        $user_data = User::create([
            'email' => $request->get('email_id'),
            'activated'  => 1,
            'user_type' => 4,
            'password' => Hash::make($password)
        ]);

        Mail::send('emails.applicant', ['f_name'=>$name,'name' => $user , 'password' => $password, 'home_url' => $home_url], function($message)use ($user)
        {            
            $send_email = $message->from('devlearnexam@gmail.com')->to($user)->subject('Applicant Registration');
        });
        return redirect()->route('applicant.list_applicant');
    }
    public function list_applicant(){
        $applicant_list = Applicant::where("isDeleted", "=", 0)->where("author_id","=",Auth::user()->id)->orderBy('id','DESC')->paginate(500);
        return view('client.agency.list_applicant',compact('applicant_list'));
    }
    public function app_edit(Request $request){
        $applicant_details = Applicant::find($request->get('id'));
        return view('client.agency.app_edit',compact('applicant_details'));
    }
    public function app_update(Request $request , $id){
        Applicant::find($id)->update($request->all());
        return redirect()->route('applicant.list_applicant');
    }
    public function app_delete(Request $request , $id){
        Applicant::find($request->get('id'))->update(['isDeleted' => 1]);
        return redirect()->route('applicant.list_applicant');
    }
    public function agency_assoc(){
        return view('client.agency.agency_assoc');
    }
    public function final_associate_agency(Request $request){
        $email = $request->get('email');
        $agency_assoc_url = URL('/company_services');

        Mail::send('emails.agency_assoc', ['email'=>$email, 'com_url' => $agency_assoc_url], function($message)use ($email)
        {            
            $send_email = $message->from('devlearnexam@gmail.com')->to($email)->subject('Request from Agency');
        });

        $associate_agency = Job::where("author_id", "=", $email)->update(['associate_agency' => 1,'associate_user' => Auth::user()->email]);
        return redirect()->route('agency.associate');
    }

    public function find_company(){
        return view('client.agency.find_company');
    }
    public function find_company_post(Request $request){
        $byemail = $request->get('search_by_email');
        $id = $request->get('id_search');
        $name = $request->get('search_by_name');
        $city = $request->get('location');
        if($id){
            $company_data = Company::where('id', '=',$id)->orderBy('created_at','desc')->paginate(15);    
        }
        else{
            $company_data = Company::where('email_id', 'LIKE', '%' . $byemail . '%')->where('business_name', 'LIKE', '%' . $name . '%')->where('city', 'LIKE', '%' . $city . '%')->orderBy('created_at','desc')->paginate(15);
        }

        return view('client.agency.find_company',compact('company_data'));
    }
    public function invite_company(Request $request){
        $get_comp_id = $request->get('id');
        $company_query = Company::find($get_comp_id);
        $company_email = $company_query['email_id'];
        $home_url = URL('/');

        Mail::send('emails.agency_assoc', ['email'=>$company_email, 'com_url' => $home_url], function($message)use ($company_email)
            {            
                $send_email = $message->from('devlearnexam@gmail.com')->to($company_email)->subject('Request for Associate');
            });
        return redirect::back()->with('message','Email Sent to Company');
    }
}
