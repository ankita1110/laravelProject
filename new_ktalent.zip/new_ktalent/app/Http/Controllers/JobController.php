<?php

namespace App\Http\Controllers;

ini_set('memory_limit','-1');

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Job;
use Auth;
use View, Redirect, App, Illuminate\Support\Facades\URL, Config;
class JobController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $job = Job::where("isDeleted", "=", 0)->orderBy('id','DESC')->paginate(500);
        $sidebar = array(
            "Job List" => array('url' => URL::route('job.index'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('job.create'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
        );
        return view('admin.job.index')->with('i', ($request->input('page', 1) - 1) * 5)->with(["job" => $job, "request" => $request,'sidebar_items' => $sidebar]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $sidebar = array(
            "Job List" => array('url' => URL::route('job.index'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('job.create'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
        );
        return view('admin.job.create')->with(["sidebar_items"=>$sidebar]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'experience' => 'required',
            'education'=>'required',
            'technical_education'=>'required'
        ]);
        Job::create($request->all());
        return redirect()->route('job.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $job = Job::find($id);
        $sidebar = array(
            "Job List" => array('url' => URL::route('job.index'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('job.create'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
        );
        return view('admin.job.edit')->with(["job" => $job,'sidebar_items' => $sidebar]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'experience' => 'required',
            'education'=>'required',
            'technical_education'=>'required'
        ]);
        Job::find($id)->update($request->all());
        return redirect()->route('job.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Job::find($id)->update(['isDeleted' => 1]);
        return redirect()->route('job.index');
    }

    /* Post a Job Controller by Company User side */
    public function add_a_job(){
        return view('client.company.post_job');
    }
    public function company_save_job(Request $request){
        Job::create($request->all());
        return redirect()->route('job.listjob');
    }
    public function listjob(){
        $login_user = Auth::user()->email;
        $job_listing = Job::where("isDeleted", "=", 0)->where("author_id","=",$login_user)->orderBy('id','DESC')->paginate(500);
        return view('client.company.job_list',compact('job_listing'));
    }
    public function company_job_edit($id){
        $job_edit = Job::find($id);
        return view('client.company.edit_jobs',compact('job_edit'));
    }
    public function update_post_job(Request $request,$id){
        Job::find($id)->update($request->all());
        return redirect()->route('job.listjob');
    }
}
