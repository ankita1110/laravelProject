<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Applicant;
use App\Job;
use App\Http\Requests;
use Illuminate\Support\Facades\Input;
use View, Redirect, App, Illuminate\Support\Facades\URL, Config;
use App\User;
use Hash;
use Mail;
use Auth;

class ApplicantController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $applicant = Applicant::where("isDeleted", "=", 0)->orderBy('id','DESC')->paginate(500);
        $sidebar = array(
            "Applicant List" => array('url' => URL::route('applicant.index'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('applicant.create'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('applicant.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        return view('admin.applicant.index')->with('i', ($request->input('page', 1) - 1) * 5)->with(["applicant" => $applicant, "request" => $request,'sidebar_items' => $sidebar]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $sidebar = array(
            "Applicant List" => array('url' => URL::route('applicant.index'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('applicant.create'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('applicant.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        return view('admin.applicant.create')->with(['sidebar_items' => $sidebar]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'picture' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'cv'=>'required',
        ]);
        $applicant = new Applicant($request->input()) ;
        $image = Input::file('picture');
        $cv=Input::file('cv');
        if(isset($image)){
            $fileName = date('Y-m-d-H-i-s')."-".$image->getClientOriginalName() ;
            $destinationPath = public_path().'/app/public/images/applicant/' ;
            $image->move($destinationPath,$fileName);
            $applicant->picture = $fileName ;
        }
        if(isset($cv)){
            $cvName = date('Y-m-d-H-i-s')."-".$cv->getClientOriginalName() ;
            $destinationPathcv = public_path().'/app/public/cv/applicant/' ;
            $cv->move($destinationPathcv,$cvName);
            $applicant->cv = $cvName ;
        }
        $applicant->save($request->all());

        $home_url = url('/');
        $user=$request->get('email_id');
        $name = $request->get('first_name');
        $password = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
        $user_data = User::create([
            'email' => $request->get('email_id'),
            'activated'  => 1,
            'user_type' => 4,
            'password' => Hash::make($password)
        ]);
        $link=array('link' => $home_url.'/company/getInvite');
        //print_r($agencymail);
        Mail::send('emails.applicant', ['f_name'=>$name,'name' => $user,'link'=>$link , 'password' => $password, 'home_url' => $home_url], function($message)use ($user)
        {            
            $send_email = $message->from('devlearnexam@gmail.com')->to($user)->subject('Applicant Registration');
        });
        return redirect()->route('applicant.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        $applicant = Applicant::find($id);
        return view('admin.applicant.edit')->with(["applicant" => $applicant, "request" => $request]);
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        Applicant::find($id)->update($request->all());
        return redirect()->route('applicant.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Applicant::find($id)->update(['isDeleted' => 1]);
        return redirect()->route('applicant.index');
    }

    public function invite(){

        $sidebar = array(
            "Applicant List" => array('url' => URL::route('applicant.index'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('applicant.create'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('applicant.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        return view('admin.applicant.invite')->with(['sidebar_items' => $sidebar]);;
    }

    public function sendinvite(Request $request){
        $this->validate($request, [
            'email'=>'required|email',
        ]);
        $user=$request->get('email');
        $link=URL('/').'applicant/getInvite';
        Mail::send('emails.invite', ['user' => $user,'link'=>$link], function($message)use ($user)
        {
            $message
                ->from('support.hrbuddy@gmail.com')
                ->to($user)
                ->subject('Your Invitation to HRBUDDY!');
        });
        return redirect()->route('applicant.invite');
    }
    public function getInvite(){
        return view('admin.applicant.sendinvite');
    }

    public function storeInvite(Request $request)
    {
        $this->validate($request, [
            'picture' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'cv'=>'required',
        ]);
        $applicant = new Applicant($request->input()) ;
        $image = Input::file('picture');
        $cv=Input::file('cv');
        if(isset($image)){
            $fileName = date('Y-m-d-H-i-s')."-".$image->getClientOriginalName() ;
            $destinationPath = public_path().'/app/public/images/applicant/' ;
            $image->move($destinationPath,$fileName);
            $applicant->picture = $fileName ;
        }
        if(isset($cv)){
            $cvName = date('Y-m-d-H-i-s')."-".$cv->getClientOriginalName() ;
            $destinationPathcv = public_path().'/app/public/cv/applicant/' ;
            $cv->move($destinationPathcv,$cvName);
            $applicant->cv = $cvName ;
        }
        $applicant->save($request->all());

        return redirect()->route('applicant.getInvite');
    }
    public function listed_job(){
        $display_job = Job::where("isDeleted", "=", 0)->orderBy('id','DESC')->paginate(50);
        return view('client.applicant.list_jobs',compact('display_job'));
    }
    public function apply_job(Request $request){
        $job_id = $request->get('job_id');
        $auth_id = Auth::user()->id;

        $edited_update = Job::where('id', $job_id)->first();
        $auth_exist = $edited_update->apply_auth;
        $auth_exist = array($auth_exist);
        $final_up = array_push($auth_exist, $auth_id);
        $duplicate_remove = array_unique($auth_exist);
        $final_cal =implode(',', $duplicate_remove);

        $update_apply = Job::find($job_id)->update(['isApplied' => 1,'apply_auth' => $final_cal]);
        return redirect()->route('applicant.list_job');
    }
}
