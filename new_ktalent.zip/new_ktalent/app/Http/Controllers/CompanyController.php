<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
use App\Company;
use App\User;
use App\Job;
use App\Agency;
use Hash;
use Auth;
use App\Http\Requests;
use View, Redirect, App, Illuminate\Support\Facades\URL, Config;

class CompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $company = Company::where("isDeleted", "=", 0)->orderBy('id','DESC')->paginate(500);
        $sidebar = array(
            "Company List" => array('url' => URL::route('company.index'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('company.create'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('company.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        return view('admin.company.index')->with('i', ($request->input('page', 1) - 1) * 5)->with(["company" => $company, "request" => $request,'sidebar_items' => $sidebar]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $sidebar = array(
            "Company List" => array('url' => URL::route('company.index'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('company.create'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('company.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        return view('admin.company.create')->with(['sidebar_items' => $sidebar]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Company::create($request->all());
        $home_url = url('/');
        $user=$request->get('email_id');
        $link=array('link' => $home_url.'/company/getInvite');
        $c_person = $request->get('business_name');
        $password = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
        $user_data = User::create([
            'email' => $user,
            'activated'  => 1,
            'user_type' => 3,
            'password' => Hash::make($password)
        ]);
        Mail::send('emails.company_reg', ['name' => $c_person,'username'=>$user,'link'=>$home_url,'password'=>$password], function($message)use ($user)
        {            
            $send_email = $message->from('devlearnexam@gmail.com')->to($user)->subject('Company Registration');
        });
        
        return redirect()->route('company.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $company = Company::find($id);
        $sidebar = array(
            "Company List" => array('url' => URL::route('company.index'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('company.create'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('company.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        return view('admin.company.edit')->with(["company" => $company,'sidebar_items' => $sidebar]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        Company::find($id)->update($request->all());
        return redirect()->route('company.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Company::find($id)->update(['isDeleted' => 1]);
        return redirect()->route('company.index') ->withMessage(Config::get('acl_messages.flash.success.company_delete_success'));
    }

    public function invite(){
        $sidebar = array(
            "Company List" => array('url' => URL::route('company.index'), 'icon' => '<i class="fa fa-users"></i>'),
            'Add New' => array('url' => URL::route('company.create'), 'icon' => '<i class="fa fa-plus-circle"></i>'),
            'Send Invitation' => array('url' => URL::route('company.invite'), 'icon' => '<i class="fa fa-send-o"></i>'),
        );
        return view('admin.company.invite')->with(['sidebar_items' => $sidebar]);;
    }
    public function sendinvite(Request $request){
        $this->validate($request, [
            'email'=>'required|email',
        ]);
        $user=$request->get('email');
        $home_url = url('/');
        $link = $home_url.'/company/getInvite';
        Mail::send('emails.invite', ['user' => $user,'link'=>$link], function($message)use ($user)
        {
            $message
                ->from('support.hrbuddy@gmail.com')
                ->to($user)
                ->subject('Your Invitation to HRBUDDY!');
        });
        return redirect()->route('company.invite');
    }

    public function getInvite(){
        return view('admin.company.sendinvite');
    }

    public function storeInvite(Request $request)
    {
        Company::create($request->all());
        return redirect()->route('company.getInvite');
    }
    public function com_services(){
        $login_user = Auth::user()->email;
        $company = Job::where("isDeleted", "=", 0)->where("associate_agency","=",1)->where("author_id","=",$login_user)->orderBy('id','DESC')->paginate(20);
        if(count($company)!=0){
            foreach ($company as $key => $value) {
                $assoc_user = $value['associate_user'];
            }
        }
        if(count($company)==0){
            $assoc_user = "";
        }
        $user_query = Agency::where("email1","=",$assoc_user)->orderBy('id','DESC')->paginate(20);
        return view('client.company.company_service',compact('user_query'));
    }
    public function accept_company(Request $request){
        $get_comp_id = $request->get('id');
        $comp_service_url = URL('/agency_associate');
        $agency_query = Agency::where("id","=",$get_comp_id)->orderBy('id','DESC')->paginate(20);
        $agency_email = "";
        foreach ($agency_query as $key => $value) {
            $agency_email = $value['email1'];
        }
        
        if($agency_email == ""){
            echo "No Email Found";
             return redirect::back()->withErrors(['This email is not found in Agency']);
        }
        else{
            Mail::send('emails.company_service', ['email'=>$agency_email, 'com_url' => $comp_service_url], function($message)use ($agency_email)
            {            
                $send_email = $message->from('devlearnexam@gmail.com')->to($agency_email)->subject('Request for Service');
            });
            /* Associate agency 2 for confirm invitation */
            $job_user_updt = Job::where("associate_user","=",$agency_email)->update(['associate_agency' => 2]);
            return redirect()->route('company.services');
        }
    }
    public function find_agency(){
        return view('client.company.find_agency');
    }
    public function find_agency_post(Request $request){
        $byemail = $request->get('search_by_email');
        $id = $request->get('id_search');
        $name = $request->get('search_by_name');
        $city = $request->get('location');
        if($id){
            $agency_data = Agency::where('id', '=',$id)->orderBy('created_at','desc')->paginate(15);    
        }
        else{
            $agency_data = Agency::where('email1', 'LIKE', '%' . $byemail . '%')->where('name', 'LIKE', '%' . $name . '%')->where('city', 'LIKE', '%' . $city . '%')->orderBy('created_at','desc')->paginate(15);
        }

        return view('client.company.find_agency',compact('agency_data'));
    }
    public function invite_agency(Request $request){
        $get_comp_id = $request->get('id');
        $agency_query = Agency::find($get_comp_id);
        $agency_email = $agency_query['email1'];
        $home_url = URL('/');

        Mail::send('emails.company_service', ['email'=>$agency_email, 'com_url' => $home_url], function($message)use ($agency_email)
            {            
                $send_email = $message->from('devlearnexam@gmail.com')->to($agency_email)->subject('Request for Service');
            });
        return redirect::back()->with('message','Email Sent to Agency');
    }
}