<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    protected $table = 'company_field';
    protected $fillable = ["id", "business_name", "contact_person", "mobile_no", "email_id", "address", "city", "district", "state", "country", "brand_name", "legal_identity", "nature_business", "isDeleted"];
}
