<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agency extends Model
{
    protected $table = 'agency';
    protected $fillable = ["id", "name", "person1", "designation1", "contact1", "email1", "person2", "designation2", "contact2","email2", "person3", "designation3", "contact3","email3","address1","address2","address3","city","state","pin","country","isDeleted"];

}
