<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Job extends Model
{
    protected $table = 'job';
    protected $fillable = ["id", "designation", "department", "salary", "experience", "education", "technical_education", "location", "key_jobs_role","desired_skills", "other_benefits", "types_job","author_id","isApplied","apply_auth","associate_agency","associate_user","isDeleted"];

}
